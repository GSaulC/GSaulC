package Clases;

import java.io.Serializable;
import static projecto.Email.ml;

public class Multilistas implements Serializable
{

    public Nodo getR()
    {
        return r;
    }

    public void setR(Nodo r)
    {
        this.r = r;
    }
    private Nodo r = null;

    public Nodo inserta(Nodo n, String[] s, int nivel, Nodo r)
    {
        if (nivel == s.length - 1)
        {
            Listaa l = new Listaa();
            l.setR(r);
            l.inserta(n);
            r = l.getR();
            return l.getR();
        } else
        {
            Nodo aux = Buscar(r, s[nivel]);
            if (aux != null)
            {
                aux.setAbj(inserta(n, s, nivel + 1, aux.getAbj()));
            }
            return r;
        }
    }

    public Nodo busca(Nodo r, String s)
    {
        Nodo aux = r;
        while (aux != null)
        {
            if (aux.getEtiqueta().equals(s))
            {
                return aux;
            } else
            {
                if (aux.getEtiqueta().compareTo(s) > 0)
                {
                    return null;
                }
                aux = aux.getSig();
            }
        }
        return null;
    }

    public String consulta(Nodo r, String nt)
    {
        String s = "";
        while (r != null)
        {
            s += nt + r.getEtiqueta() + "\n";
            s += consulta(r.getAbj(), nt + "\t");
            r = r.getSig();
        }
        return s;
    }

    public void modificar(String nue, Nodo mod, String vieja[], String nueva[])
    {
        Nodo aux = r;
        aux = aux.getAbj();
        r = ml.elimina(r, 0, vieja);
        //System.out.println(mod.getObj() + " " + mod.getEtiqueta());
        if (mod.getObj().equals(mod.getEtiqueta()))
        {
            mod.setEtiqueta(nue);
            mod.setObj(nue);
            ml.inserta(mod, nueva, 0, r);
            //System.out.println(mod.getObj() + " " + mod.getEtiqueta());
        }
    }

    public void modificarContra(String nue, Nodo mod, String vieja[], String nueva[])
    {
        Nodo aux = r;
        r = ml.elimina(r, 0, vieja);
        //System.out.println(mod.getObj() + " " + mod.getEtiqueta());
        if (mod.getObj().equals(mod.getEtiqueta()))
        {
            mod.setEtiqueta(nue);
            mod.setObj(nue);
            if (ml.getR() != null)
            {
                ml.inserta(mod, nueva, 0, r);
            } else
            {
                r = mod;
            }
            //System.out.println(mod.getObj() + " " + mod.getEtiqueta());
        }
    }

    public Nodo buscaSin(Nodo aux, Nodo raiz, String s)
    {
        int bandera = 0;
        Nodo ruta = null;
        while (raiz != null)
        {
            if (aux.getEtiqueta().equals(s))
            {
                return ruta = aux;
            } else
            {
                if (raiz.getAbj() != null && bandera == 0)
                {
                    if (aux.getAbj() != null)
                    {
                        aux = aux.getAbj();
                        bandera = 0;
                    } else
                    {
                        if (aux.getSig() != null)
                        {
                            aux = aux.getSig();
                            bandera = 0;

                        } else
                        {
                            bandera = 1;
                        }
                    }
                } else
                {
                    raiz = raiz.getSig();
                    aux = raiz;
                }

            }
        }
        return ruta;
    }

    public Nodo elimina(Nodo r, int nivel, String etqs[])
    {
        if (nivel == etqs.length - 1)
        {
            Listaa ls = new Listaa();
            ls.setR(r);
            Nodo aux = ls.eliminar(etqs[nivel]);
            r = aux;
            if (aux == null)
            {

            } else
            {
                r = ls.getR();
            }
            return r;
        } else
        {
            Nodo aux = busca(r, etqs[nivel]);
            if (aux != null)
            {
                aux.setAbj(elimina(aux.getAbj(), nivel + 1, etqs));//recursion
            } else
            {
                //System.out.println("No se encontro " + etqs[nivel] + " En el nivel " + nivel);
            }
            return r;
        }
    }

    public Nodo eliminarr(Nodo n, String[] etqs, int level, Nodo r)
    {
        Nodo x = null;
        if (level == etqs.length - 1)
        {
            Listaa lista = new Listaa();
            lista.setR(r);
            x = lista.eliminar(n.getEtiqueta());
            //System.out.println("Nodo final" + x.getEtiqueta());
            return lista.getR();
        } else
        {
            Nodo aux = Buscar(r, etqs[level]);
            if (aux != null)
            {
                aux.setAbj(eliminarr(n, etqs, level + 1, aux.getAbj()));
            } else
            {
                //System.out.println("No se encontro " + etqs[level] + " En el nivel " + level);
            }
        }
        return x;
    }

    public static Nodo Buscar(Nodo s, String Etq)
    {
        Nodo aux = null;
        while (s != null)
        {
            if (s.getEtiqueta().equals(Etq))
            {
                return s;
            } else
            {
                s = s.getSig();
            }
        }
        return aux;
    }

    public Nodo mover(Nodo s, int nivel, String etiqs_Eli[], String etqs_Ins[])//el nivel empieza en 0
    {
        //codigo para mover
        Nodo arriba = ml.Buscar(ml.getR(), etiqs_Eli[0]);
        arriba = arriba.getAbj();
        arriba = ml.Buscar(arriba, etiqs_Eli[1]);
        arriba = arriba.getAbj();
        Nodo aux = arriba;
        arriba = ml.Buscar(arriba, etiqs_Eli[2]);
        s = elimina(s, nivel, etiqs_Eli);
        if (s != null)
        {
            s = inserta(arriba, etqs_Ins, nivel, ml.getR());
            s.setAnt(arriba);
        }
        return s;
    }

    public Nodo moverb(Nodo s, int nivel, String etqsE[], String etqsI[])
    {
        s = elimina(s, nivel, etqsE);
        if (r != null)
        {
            s.setEtiqueta(etqsI[2]);
            //System.out.println("Nodo final FINAL" + s.getEtiqueta());
            s = inserta(s, etqsI, nivel, r);
            //System.out.println("Nodo final FINAL" + s.getEtiqueta());
        }

        return s;

    }

}
