package Clases;

import java.io.Serializable;

public class NodoArbol<T> implements Serializable
{

    private T obj;
    private NodoArbol izq;
    private NodoArbol der;
    private String etiq;

    public NodoArbol(T obj, String etiq)
    {
        this.obj = obj;
        izq = der = null;
        this.etiq = etiq;
    }

    public T getObj()
    {
        return obj;
    }

    public void setObj(T obj)
    {
        this.obj = obj;
    }

    public NodoArbol getIzq()
    {
        return izq;
    }

    public void setIzq(NodoArbol izq)
    {
        this.izq = izq;
    }

    public NodoArbol getDer()
    {
        return der;
    }

    public void setDer(NodoArbol der)
    {
        this.der = der;
    }

    public String getEtiq()
    {
        return etiq;
    }

    public void setEtiq(String etiq)
    {
        this.etiq = etiq;
    }

}
