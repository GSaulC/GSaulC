package Clases;

import java.io.Serializable;
import javax.swing.JOptionPane;

public class TablasHash implements Serializable
{

    private ArbolBinario arr[];

    public TablasHash(int n)
    {
        arr = new ArbolBinario[n];
        for (int i = 0; i < n; i++)
        {
            arr[i] = new ArbolBinario();
        }
    }

    public static int posicion(NodoArbol b)
    {
        char de = b.getEtiq().charAt(0);
        int pos = 0;

        for (int i = 65; i < 91; i++)
        {

            if (i == de)
            {
                pos = i - 65;
            }
        }
        //System.out.println("La posicion es " + pos);
        return pos;
    }

    public void insertaTH(String etq, NodoArbol nuevo)
    {

        int pos = posicion(nuevo);
        if (pos == -1)
        {
            JOptionPane.showMessageDialog(null, "Nombre no aceptado");
        } else
        {
            arr[pos].setR(arr[pos].inserta(arr[pos].getR(), nuevo));
        }
    }

    public void elimina(String etq)
    {
        int pos = etq.codePointAt(0) - 65;
        if (pos == -1)
        {

        } else
        {
            NodoArbol[] arrE = new NodoArbol[2];
            arr[pos].elimina(etq, arrE, arr[pos].getR());
            arr[pos].setR(arrE[1]);
        }

    }

    public String[] busqueda(String bus)
    {
        String posC = bus;
        //System.out.println(bus);
        String lis[] = null;
        String cad = "";
        String busret[] = null;
        int dee = bus.codePointAt(0);
        //System.out.println("Primera letra: " + dee);
        int list = 0;
        int pos = 0;
        pos = dee - 65;
        //System.out.println("POSICION FINAL: " + pos);
        for (int i = 0; i < arr.length; i++)
        {
            if (pos == i)
            {
                String ar = arr[i].PreOrden(arr[i].getR());
                lis = ar.split(";");
                if (lis[0].equals("") || lis[0].equals(";"))
                {
                    return busret = null;
                } else
                {
                    for (int j = 0; j < lis.length; j++)
                    {
                        for (int k = 0; k < bus.length(); k++)
                        {
                            if (bus.equals(lis[j].substring(0, k + 1)))
                            {
                                cad += lis[j] + ";";
                                break;
                            }
                        }
                    }
                }
            }
        }
        busret = cad.split(";");
        return busret;
    }

    public void verarboles()
    {
        for (int i = 0; i < arr.length; i++)
        {
            //System.out.println("Arbol [" + i + "] " + arr[i].PreOrden(arr[i].getR()) + "\n");
        }
    }

    /**
     * @return the arr
     */
    public ArbolBinario[] getArr()
    {
        return arr;
    }

    /**
     * @param arr the arr to set
     */
    public void setArr(ArbolBinario[] arr)
    {
        this.arr = arr;
    }
}
