package Clases;

import java.io.Serializable;

public class ArbolBinario implements Serializable
{

    public NodoArbol getR()
    {
        return r;
    }

    public void setR(NodoArbol r)
    {
        this.r = r;
    }
    private NodoArbol r = null; //La raiz
    // no se necesita constructor

    public NodoArbol inserta(NodoArbol r, NodoArbol n)
    {
        if (r == null)
        {
            return n;
        } else
        {
            if (n.getEtiq().compareTo(r.getEtiq()) <= 0)
            {
                r.setIzq(inserta(r.getIzq(), n));
            } else
            {
                r.setDer(inserta(r.getDer(), n));
            }
            return r;
        }
    }

    public String InOrden(NodoArbol r)
    {
        String s = "";
        if (r != null)
        {
            s += InOrden(r.getIzq());
            s += r.getEtiq();
            s += InOrden(r.getDer());
        }
        return s;
    }

    //Examen pre, in, pos
    public String PreOrden(NodoArbol r)
    {
        String s = "";
        if (r != null)
        {
            s += r.getEtiq() + ";";
            s += PreOrden(r.getIzq());
            s += PreOrden(r.getDer());
        }
        return s;
    }

    public String PosOrden(NodoArbol r)
    {
        String s = "";
        if (r != null)
        {
            s += PosOrden(r.getIzq());
            s += PosOrden(r.getDer());
            s += r.getEtiq();
        }
        return s;
    }

    public NodoArbol[] elimina(String e, NodoArbol d[], NodoArbol r)
    {
        if (r != null)
        {
            if (!r.getEtiq().equals(e))
            {
                if (r.getEtiq().compareTo(e) > 0)
                {
                    d = elimina(e, d, r.getIzq());
                    r.setIzq(d[0]);
                } else
                {
                    d = elimina(e, d, r.getDer());
                    r.setDer(d[0]);
                }
                d[0] = r;
            } else
            {
                d[1] = r;
                if (r.getIzq() == null && r.getDer() == null)
                {
                    d[0] = null;
                } else
                {
                    if (!(r.getIzq() != null && r.getDer() != null))
                    {
                        if (r.getIzq() != null)
                        {
                            d[0] = r.getIzq();
                        } else
                        {
                            d[0] = r.getDer();
                        }
                    } else
                    {
                        if (r.getDer().getIzq() == null)
                        {
                            d[0] = r.getDer();
                            d[0].setIzq(r.getIzq());
                        } else
                        {
                            NodoArbol se = sucesor(r.getDer()); //se = sucesor en orden
                            d[0] = se.getIzq();
                            se.setIzq(d[0].getDer());
                            d[0].setIzq(r.getIzq());
                            d[0].setDer(r.getDer());

                        }
                    }
                }
                d[1].setIzq(null);
                d[1].setDer(null);
            }
            return d;
        } else
        {
            d[0] = null;
            return d;
        }
    }

    public NodoArbol sucesor(NodoArbol r)
    {
        if (r.getIzq().getIzq() != null)
        {
            return sucesor(r.getIzq());
        } else
        {
            return r;
        }
    }
}
