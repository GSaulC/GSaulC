package Clases;

import java.io.Serializable;

public class Nodo<T> implements Serializable
{

    public void setSig(Nodo sig)
    {
        this.sig = sig;
    }

    public Nodo getAbj()
    {
        return abj;
    }

    public void setAbj(Nodo abj)
    {
        this.abj = abj;
    }

    public Nodo getAnt()
    {
        return ant;
    }

    public void setAnt(Nodo ant)
    {
        this.ant = ant;
    }

    private T obj;
    private Nodo sig;
    String etiqueta;
    private Nodo ant;
    private Nodo abj;

    public String getEtiqueta()
    {
        return etiqueta;
    }

    public void setEtiqueta(String etiqueta)
    {
        this.etiqueta = etiqueta;
    }

    public Nodo getSig()
    {
        return sig;
    }

    public T getObj()
    {
        return obj;
    }

    public void setObj(T obj)
    {
        this.obj = obj;
    }

    public Nodo(T obj, String etiqueta)
    {
        this.obj = obj;
        sig = null;
        this.etiqueta = etiqueta;

    }

    public String desp()
    {
        try
        {
            return obj.toString();
        } catch (Exception err)
        {
            //System.out.println("error" + err.toString());
            return " ";
        }
    }

}
