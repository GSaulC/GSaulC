package Clases;

import java.io.Serializable;

public class Listaa implements Serializable
{

    public Nodo getR()
    {
        return r;
    }

    public void setR(Nodo r)
    {
        this.r = r;
    }
    private Nodo r = null;

    public boolean inserta(Nodo n)
    {
        if (n != null)
        {
            if (r == null)
            {
                r = n;
                return true;
            } else
            {
                if (n.getEtiqueta().compareTo(r.getEtiqueta()) <= 0) //Compara cadenas, se pone < 0
                {
                    n.setSig(r); //El bebe mas chico se va a Raquel
                    r = n; //Raquel se va con el niño
                    return true;
                } else
                {
                    Nodo aux = r;
                    while (aux.getSig() != null)
                    {
                        if (n.getEtiqueta().compareTo(aux.getSig().getEtiqueta()) < 0)
                        {
                            n.setSig(aux.getSig());
                            aux.setSig(n);
                            return true;
                        } else
                        {
                            aux = aux.getSig();
                        }
                    }
                    aux.setSig(n);
                    return true;
                }
            }
        }
        return false;
    }

    public void desp()
    {
        Nodo aux = r;
        while (aux != null)
        {
            //System.out.println(aux.getEtiqueta());
            aux = aux.getSig();
        }
    }

    public void desp(Nodo r)
    {
        if (r != null)
        {
            //System.out.println(r.getEtiqueta());
            desp(r.getSig());
        }
    }

    public void despp(Nodo r)
    {
        Nodo aux = r;
        while (aux.getSig() != null)
        {
            aux = aux.getSig();
        }
        while (aux != null)
        {
            //System.out.println(aux.getEtiqueta());
            aux = aux.getAnt();
        }
    }

    public Nodo eliminar(String etiq)
    {
        if (r == null)//No debe estar vacio
        {
            return null;
        } else
        {

            Nodo aux = null;
            if (etiq.compareTo(r.getEtiqueta()) >= 0)//Si es mayor o igual a 0
            {
                if (r.getEtiqueta().equals(etiq))
                {
                    aux = r;
                    r = r.getSig();
                    aux.setSig(null);
                } else
                {
                    Nodo aux2 = r;
                    boolean b = true;
                    while (aux2.getSig() != null && b)
                    {
                        if (aux2.getSig().getEtiqueta().equals(etiq))
                        {
                            aux = aux2.getSig();
                            aux2.setSig(aux.getSig());
                            aux.setSig(null);
                            b = false;
                        } else
                        {
                            aux2 = aux2.getSig();
                        }
                    }
                }
            }
            return aux;
        }
    }
}
