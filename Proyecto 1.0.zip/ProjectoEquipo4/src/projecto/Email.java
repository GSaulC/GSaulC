package projecto;

import Clases.Multilistas;
import Clases.Nodo;
import Clases.NodoArbol;
import Clases.TablasHash;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;

public class Email extends javax.swing.JFrame
{
    
    public Nodo raizCat;
    boolean x = true;
    public Nodo r1;
    int nn1 = 0;
    int nn2 = 0;
    public static Multilistas ml;
    String nv;
    String nv2;
    String nv3;
    boolean bt = true;
    boolean bt2 = true;
    Font f = new Font("Tahoma", Font.BOLD, 15);
    String contra;
    Border border = new LineBorder(new Color(245, 245, 245), 5, true);
    Color col = new Color(255, 153, 102);
    Color col2 = new Color(204, 255, 51);
    Color col3 = new Color(0, 153, 255);
    Color col4 = new Color(51, 255, 102);
    Color col5 = new Color(255, 102, 102);
    Color col6 = new Color(255, 153, 51);
    Color col7 = new Color(153, 51, 255);
    Color col8 = new Color(255, 51, 0);
    Color col9 = new Color(51, 255, 153);
    Color col10 = new Color(0, 51, 102);
    Color col11 = new Color(255, 255, 51);
    Color col12 = new Color(245, 245, 245);
    Color nc = new Color(245, 245, 245);
    boolean opci = true;
    public static TablasHash tha;
    boolean colo = true;
    boolean agr = true;
    boolean moif = true;
    int muestra;
    public static Nodo ax;
    public static ArrayList<Nodo> Corr = new ArrayList<>();
    public static ArrayList<String> Corr2 = new ArrayList<>();
    
    public Email()
    {
        initComponents();
        try
        {
            ObjectInputStream file = new ObjectInputStream(new FileInputStream("mlistas.dat"));
            ml = (Multilistas) file.readObject();
            file.close();
        } catch (ClassNotFoundException ex)
        {
            //System.out.println("Compruebe la clase");
        } catch (IOException e)
        {
            //System.out.println("No existe el archivo");
            //Al no existir el archivo lo instancia como nuevo objeto
            ml = new Multilistas();
        }
        try
        {
            ObjectInputStream file = new ObjectInputStream(new FileInputStream("tablas.dat"));
            tha = (TablasHash) file.readObject();
            file.close();
        } catch (ClassNotFoundException ex)
        {
            //System.out.println("Compruebe la clase");
        } catch (IOException e)
        {
            //System.out.println("No existe el archivo");
            //Al no existir el archivo lo instancia como nuevo objeto
            tha = new TablasHash(26);
        }
        
        addWindowListener(new WindowAdapter()
        {
            public void windowClosing(WindowEvent we)
            {
                UIManager.put("control", nc);
                UIManager.put("OptionPane.messageFont", f);
                int confirm = JOptionPane.showConfirmDialog(null, "¿Deseas salir del programa?");
                if (confirm == JOptionPane.YES_OPTION)
                {
                    try
                    {
                        ObjectOutputStream file = new ObjectOutputStream(new FileOutputStream("mlistas.dat"));
                        file.writeObject(ml);
                        file.close();
                    } catch (IOException ex)
                    {
                        //System.out.println("No se encontro archivo");
                    }
                    try
                    {
                        ObjectOutputStream file = new ObjectOutputStream(new FileOutputStream("tablas.dat"));
                        file.writeObject(tha);
                        file.close();
                    } catch (IOException ex)
                    {
                        //System.out.println("No se encontro archivo");
                    }
                    System.exit(0);
                }
            }
        });
        bConfCuentas.setVisible(false);
        bConfCuentas.setLocation(100, 560);
        bRegresar.setVisible(false);
        bRegresar.setLocation(991, 500);
        jLabel12.setBounds(0, 0, 900, 700);
        jLabel12.setVisible(true);
        bMoverC.setVisible(false);
        jButton23.setVisible(false);
        bEnviarC.setLocation(1080, 15);
        jButton23.setLocation(1060, 7);
        bMoverC.setLocation(612, 61);
        jScrollPane4.setBounds(710, 80, 450, 200);
        jPanel10.setBounds(710, 50, 450, 280);
        jPanel7.setLayout(new BoxLayout(jPanel7, BoxLayout.PAGE_AXIS));
        jPanel9.setLayout(new BoxLayout(jPanel9, BoxLayout.PAGE_AXIS));
        jPanel2.setLayout(new BoxLayout(jPanel2, BoxLayout.PAGE_AXIS));
        jPanel5.setLayout(new BoxLayout(jPanel5, BoxLayout.PAGE_AXIS));
        bElimina.setVisible(false);
        bRegresa.setVisible(false);
        bRegresa.setLocation(730, 285);
        bElimina.setLocation(1025, 285);
        jLabel11.setVisible(false);
        jComboBox1.setVisible(false);
        jComboBox1.setBounds(770, 75, 350, 30);
        jLabel11.setBounds(710, 50, 450, 30);
        jPanel10.setVisible(false);
        jScrollPane4.setVisible(false);
        jButton17.setVisible(false);
        jButton17.setLocation(582, 65);
        pan.setVisible(false);
        bPersonalizar.setVisible(false);
        bCerrarS.setVisible(false);
        jScrollPane3.setBorder(border);
        jTextArea1.setBorder(border);
        bEnviarC.setVisible(false);
        jButton12.setVisible(false);
        jLabel10.setVisible(false);
        jLabel9.setVisible(false);
        jPanel7.setBackground(new Color(245, 245, 245));
        jTextArea1.setBackground(new Color(245, 245, 245));
        jLabel9.setBounds(660, 0, 540, 700);
        jScrollPane3.setBackground(new Color(245, 245, 245));
        jTextField5.setVisible(false);
        jTextField4.setVisible(false);
        jTextField3.setVisible(false);
        jTextField3.setVisible(false);
        jScrollPane3.setVisible(false);
        bEnviarC.setLocation(1110, 15);
        jTextField3.setBounds(776, 60, 370, 30);
        jTextField4.setBounds(776, 100, 370, 30);
        jTextField5.setBounds(776, 140, 370, 30);
        jScrollPane3.setBounds(776, 180, 370, 430);
        jLabel10.setBounds(770, 610, 370, 30);
        jLabel7.setVisible(false);
        jLabel6.setVisible(false);
        jLabel8.setVisible(false);
        jLabel7.setBounds(680, 60, 100, 20);
        jLabel8.setBounds(680, 100, 100, 20);
        jLabel6.setBounds(680, 140, 100, 20);
        jLabel6.setVisible(false);
        bBuscar.setVisible(false);
        bBuscar.setLocation(512, 60);
        jLabel5.setVisible(false);
        jTextField2.setVisible(false);
        jTextField2.setBounds(290, 60, 220, 30);
        jLabel5.setBounds(290, 20, 350, 20);
        jButton11.setLocation(550, 65);
        jScrollPane2.setVisible(false);
        jScrollPane2.setBounds(290, 100, 350, 550);
        jPanel6.setVisible(false);
        jPanel6.setBounds(265, 0, 400, 700);
        jButton21.setVisible(false);
        jButton12.setVisible(false);
        jButton8.setVisible(false);
        jButton7.setVisible(false);
        bCarpetas.setVisible(false);
        bCuentas.setVisible(false);
        jPanel3.setVisible(false);
        jLabel1.setVisible(false);
        jLabel2.setVisible(false);
        jTextField1.setVisible(false);
        jPasswordField1.setVisible(false);
        jPanel8.setBounds(900, 0, 300, 700);
        bInicarS.setBounds(945, 100, 200, 50);
        bRegistro.setBounds(945, 200, 200, 50);
        bMenu.setVisible(false);
        jLabel3.setVisible(false);
        jLabel4.setVisible(false);
        jButton9.setVisible(false);
        jPanel4.setVisible(false);
        jScrollPane1.setVisible(false);
        jButton10.setVisible(false);
        jButton11.setVisible(false);
        jPanel11.setVisible(false);
        jPanel11.setLayout(new GridLayout(0, 1));
        
        pan.setLayout(new GridLayout(6, 1));
        Color vc[] = new Color[12];
        vc[0] = col;
        vc[1] = col2;
        vc[2] = col3;
        vc[3] = col4;
        vc[4] = col5;
        vc[5] = col6;
        vc[6] = col7;
        vc[7] = col8;
        vc[8] = col9;
        vc[9] = col10;
        vc[10] = col11;
        vc[11] = col12;
        
        for (int i = 0; i < 12; i++)
        {
            JButton bn = new JButton();
            bn.setBackground(vc[i]);
            bn.setCursor(new Cursor(Cursor.HAND_CURSOR));
            bn.setOpaque(false);
            bn.setBorder(new LineBorder(vc[i], 5, true));
            pan.add(bn);
            bn.addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent e)
                {
                    jPanel3.setBackground(bn.getBackground());
                    jPanel8.setBackground(bn.getBackground());
                    jPanel8.setBorder(new LineBorder(bn.getBackground(), 5, true));
                    nc = bn.getBackground();
                    jPanel9.setBackground(nc);
                    jPanel9.setBorder(new LineBorder(nc, 5, true));
                    //jPanel10.setBorder(new LineBorder(nc, 15, true));
                    UIManager.put("control", nc);
                    pan.setVisible(false);
                    colo = true;
                }
            });
        }
        String nom[] = new String[2];
        nom[0] = "Eliminar cuenta";
        nom[1] = "Modificar cuenta";
        for (int j = 0; j < nom.length; j++)
        {
            JButton bn = new JButton(nom[j]);
            bn.setBackground(nc);
            bn.setCursor(new Cursor(Cursor.HAND_CURSOR));
            bn.setOpaque(false);
            bn.setFont(f);
            bn.setBorder(new LineBorder(Color.BLACK, 5, true));
            jPanel11.add(bn);
            bn.addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent e)
                {
                    jPanel11.setVisible(false);
                    jButton23.setVisible(false);
                    opci = true;
                    if ("Eliminar cuenta".equals(bn.getText()))
                    {
                        UIManager.put("control", nc);
                        UIManager.put("OptionPane.messageFont", f);
                        String cor[] = nv.split("# ");
                        int confirm = JOptionPane.showConfirmDialog(null, "Se eliminará la cuenta " + cor[0] + ", ¿estas seguro?");
                        if (confirm == JOptionPane.YES_OPTION)
                        {
                            String etqs[] = new String[1];
                            etqs[0] = nv;
                            ml.setR(ml.elimina(ml.getR(), 0, etqs));
                            UIManager.put("control", nc);
                            UIManager.put("OptionPane.messageFont", f);
                            JOptionPane.showMessageDialog(null, "Cuenta eliminada. Regresara al menú principal");
                            login();
                            borraCuadroElimina();
                            des();
                            elimAgr();
                            jPanel8.setVisible(true);
                            jPanel8.setBounds(900, 0, 300, 700);
                            jPanel3.setVisible(false);
                            jScrollPane1.setVisible(false);
                            jPanel4.setVisible(false);
                            bMenu.setVisible(false);
                            bPersonalizar.setVisible(false);
                            bCerrarS.setVisible(false);
                            bCuentas.setVisible(false);
                            bCarpetas.setVisible(false);
                            jButton10.setVisible(false);
                            jButton8.setVisible(false);
                            jButton12.setVisible(false);
                            bInicarS.setVisible(true);
                            bRegistro.setVisible(true);
                            jLabel12.setVisible(true);
                            bConfCuentas.setVisible(false);
                            x = true;
                            jPanel3.setBounds(0, 0, 70, 700);
                        }
                    } else
                    {
                        String contras = "";
                        UIManager.put("control", nc);
                        UIManager.put("OptionPane.messageFont", f);
                        contras = JOptionPane.showInputDialog("Ingresa la nueva contraseña");
                        if (!"".equals(contras))
                        {
                            String eqs[] = nv.split("# ");
                            String cc = eqs[0] + "# " + contras;
                            Nodo aux = ml.busca(ml.getR(), nv);
                            String vi[] = new String[1];
                            vi[0] = nv;
                            String vi2[] = new String[1];
                            vi2[0] = cc;
                            ml.modificarContra(cc, aux, vi, vi2);
                            UIManager.put("control", nc);
                            UIManager.put("OptionPane.messageFont", f);
                            JOptionPane.showMessageDialog(null, "Contraseña modificada de la cuenta " + eqs[0] + ". Se cerrará la sesión");
                            login();
                            borraCuadroElimina();
                            des();
                            elimAgr();
                            jPanel8.setVisible(true);
                            jPanel8.setBounds(900, 0, 300, 700);
                            jPanel3.setVisible(false);
                            jScrollPane1.setVisible(false);
                            jPanel4.setVisible(false);
                            bMenu.setVisible(false);
                            bPersonalizar.setVisible(false);
                            bCerrarS.setVisible(false);
                            bCuentas.setVisible(false);
                            bCarpetas.setVisible(false);
                            jButton10.setVisible(false);
                            jButton8.setVisible(false);
                            jButton12.setVisible(false);
                            bInicarS.setVisible(true);
                            bRegistro.setVisible(true);
                            jLabel12.setVisible(true);
                            bConfCuentas.setVisible(false);
                            x = true;
                            jPanel3.setBounds(0, 0, 70, 700);
                        } else
                        {
                            UIManager.put("control", nc);
                            UIManager.put("OptionPane.messageFont", f);
                            JOptionPane.showMessageDialog(null, "Debe escribir una contraseña válida");
                        }
                    }
                }
            });
        }
        pan.setBounds(50, 84, 150, 150);
        jPanel11.setBounds(200, 545, 200, 100);
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents()
    {

        jPanel1 = new javax.swing.JPanel();
        jButton23 = new javax.swing.JButton();
        jPanel11 = new javax.swing.JPanel();
        bConfCuentas = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        jButton21 = new javax.swing.JButton();
        bRegresar = new javax.swing.JButton();
        bInicarS = new javax.swing.JButton();
        bRegistro = new javax.swing.JButton();
        jComboBox1 = new javax.swing.JComboBox<>();
        bMoverC = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        bRegresa = new javax.swing.JButton();
        bElimina = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        jPanel9 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        pan = new javax.swing.JPanel();
        bCerrarS = new javax.swing.JButton();
        bPersonalizar = new javax.swing.JButton();
        jPanel4 = new javax.swing.JScrollPane();
        jPanel2 = new javax.swing.JPanel();
        jButton8 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel5 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jButton9 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jButton12 = new javax.swing.JButton();
        jButton17 = new javax.swing.JButton();
        bCarpetas = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        bCuentas = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jPasswordField1 = new javax.swing.JPasswordField();
        jTextField1 = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        bMenu = new javax.swing.JButton();
        jPanel8 = new javax.swing.JPanel();
        jButton11 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        bBuscar = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jPanel7 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jTextField3 = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jTextField4 = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();
        bEnviarC = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel12 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setMinimumSize(new java.awt.Dimension(1200, 700));
        setResizable(false);
        getContentPane().setLayout(null);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(null);

        jButton23.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/guardar (2).png"))); // NOI18N
        jButton23.setToolTipText("Guardar borrador");
        jButton23.setBorderPainted(false);
        jButton23.setContentAreaFilled(false);
        jButton23.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton23.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                jButton23ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton23);
        jButton23.setBounds(640, 40, 50, 50);

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        jPanel1.add(jPanel11);
        jPanel11.setBounds(440, 390, 100, 100);

        bConfCuentas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/configurar (1).png"))); // NOI18N
        bConfCuentas.setToolTipText("Ajustes de la cuenta");
        bConfCuentas.setBorderPainted(false);
        bConfCuentas.setContentAreaFilled(false);
        bConfCuentas.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        bConfCuentas.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                bConfCuentasActionPerformed(evt);
            }
        });
        jPanel1.add(bConfCuentas);
        bConfCuentas.setBounds(210, 360, 70, 70);

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setText("LLena todos los campos");
        jPanel1.add(jLabel10);
        jLabel10.setBounds(520, 230, 220, 22);

        jButton21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/m_Edit-pencil-outline-in-circular-button.svg.png"))); // NOI18N
        jButton21.setToolTipText("Modificar");
        jButton21.setBorderPainted(false);
        jButton21.setContentAreaFilled(false);
        jButton21.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton21.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                jButton21ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton21);
        jButton21.setBounds(200, 210, 20, 30);

        bRegresar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/m_484235.png"))); // NOI18N
        bRegresar.setToolTipText("Regresar");
        bRegresar.setBorderPainted(false);
        bRegresar.setContentAreaFilled(false);
        bRegresar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        bRegresar.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                bRegresarActionPerformed(evt);
            }
        });
        jPanel1.add(bRegresar);
        bRegresar.setBounds(110, 419, 100, 100);

        bInicarS.setBackground(new java.awt.Color(255, 255, 255));
        bInicarS.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        bInicarS.setText("Iniciar Sesión");
        bInicarS.setToolTipText("");
        bInicarS.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 6, true));
        bInicarS.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        bInicarS.setDefaultCapable(false);
        bInicarS.setRolloverEnabled(false);
        bInicarS.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                bInicarSActionPerformed(evt);
            }
        });
        jPanel1.add(bInicarS);
        bInicarS.setBounds(460, 20, 50, 40);

        bRegistro.setBackground(new java.awt.Color(255, 255, 255));
        bRegistro.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        bRegistro.setText("Registrarse");
        bRegistro.setToolTipText("");
        bRegistro.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 6, true));
        bRegistro.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        bRegistro.setDebugGraphicsOptions(javax.swing.DebugGraphics.NONE_OPTION);
        bRegistro.setDefaultCapable(false);
        bRegistro.setFocusable(false);
        bRegistro.setRequestFocusEnabled(false);
        bRegistro.setRolloverEnabled(false);
        bRegistro.setVerifyInputWhenFocusTarget(false);
        bRegistro.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                bRegistroActionPerformed(evt);
            }
        });
        jPanel1.add(bRegistro);
        bRegistro.setBounds(520, 10, 60, 40);

        jComboBox1.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jComboBox1.setToolTipText("");
        jComboBox1.setBorder(null);
        jPanel1.add(jComboBox1);
        jComboBox1.setBounds(480, 150, 130, 28);

        bMoverC.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Share-PNG-Image-HD (3).png"))); // NOI18N
        bMoverC.setToolTipText("Mover correos");
        bMoverC.setBorderPainted(false);
        bMoverC.setContentAreaFilled(false);
        bMoverC.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        bMoverC.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                bMoverCActionPerformed(evt);
            }
        });
        jPanel1.add(bMoverC);
        bMoverC.setBounds(530, 70, 30, 30);

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel11.setText("Selecciona los correos a eliminar");
        jPanel1.add(jLabel11);
        jLabel11.setBounds(280, 270, 247, 19);

        bRegresa.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        bRegresa.setText("Regresar");
        bRegresa.setBorderPainted(false);
        bRegresa.setContentAreaFilled(false);
        bRegresa.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        bRegresa.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                bRegresaActionPerformed(evt);
            }
        });
        jPanel1.add(bRegresa);
        bRegresa.setBounds(340, 130, 120, 30);

        bElimina.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        bElimina.setText("Eliminar");
        bElimina.setBorderPainted(false);
        bElimina.setContentAreaFilled(false);
        bElimina.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        bElimina.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                bEliminaActionPerformed(evt);
            }
        });
        jPanel1.add(bElimina);
        bElimina.setBounds(230, 130, 110, 30);

        jScrollPane4.setBackground(new java.awt.Color(245, 245, 245));
        jScrollPane4.setBorder(null);
        jScrollPane4.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        jPanel9.setBackground(new java.awt.Color(245, 245, 245));
        jPanel9.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(245, 245, 245), 5, true));

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        jScrollPane4.setViewportView(jPanel9);

        jPanel1.add(jScrollPane4);
        jScrollPane4.setBounds(480, 250, 60, 70);

        jPanel10.setBackground(new java.awt.Color(255, 255, 255));
        jPanel10.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 5, true));

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 40, Short.MAX_VALUE)
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        jPanel1.add(jPanel10);
        jPanel10.setBounds(340, 80, 50, 40);

        javax.swing.GroupLayout panLayout = new javax.swing.GroupLayout(pan);
        pan.setLayout(panLayout);
        panLayout.setHorizontalGroup(
            panLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        panLayout.setVerticalGroup(
            panLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        jPanel1.add(pan);
        pan.setBounds(330, 320, 100, 100);

        bCerrarS.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/loggou (3).png"))); // NOI18N
        bCerrarS.setToolTipText("Cerrar Sesión");
        bCerrarS.setBorderPainted(false);
        bCerrarS.setContentAreaFilled(false);
        bCerrarS.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        bCerrarS.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                bCerrarSActionPerformed(evt);
            }
        });
        jPanel1.add(bCerrarS);
        bCerrarS.setBounds(190, 13, 60, 70);

        bPersonalizar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/pintt (2).png"))); // NOI18N
        bPersonalizar.setToolTipText("Personalizar");
        bPersonalizar.setBorderPainted(false);
        bPersonalizar.setContentAreaFilled(false);
        bPersonalizar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        bPersonalizar.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                bPersonalizarActionPerformed(evt);
            }
        });
        jPanel1.add(bPersonalizar);
        bPersonalizar.setBounds(100, 15, 60, 60);

        jPanel4.setBackground(new java.awt.Color(254, 254, 254));
        jPanel4.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(254, 254, 254), 5, true));
        jPanel4.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jPanel4.setViewportBorder(new javax.swing.border.LineBorder(new java.awt.Color(254, 254, 254), 5, true));
        jPanel4.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        jPanel2.setBackground(new java.awt.Color(254, 254, 254));
        jPanel2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(254, 254, 254), 5, true));
        jPanel2.setToolTipText("");
        jPanel2.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jPanel2.setLayout(new java.awt.GridLayout(1, 0));
        jPanel4.setViewportView(jPanel2);

        jPanel1.add(jPanel4);
        jPanel4.setBounds(390, 210, 90, 60);

        jButton8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/m_Agregar.png"))); // NOI18N
        jButton8.setToolTipText("Crear");
        jButton8.setBorderPainted(false);
        jButton8.setContentAreaFilled(false);
        jButton8.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton8.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                jButton8ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton8);
        jButton8.setBounds(150, 300, 20, 20);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Correo");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(700, 20, 80, 29);

        jScrollPane1.setBackground(new java.awt.Color(254, 254, 254));
        jScrollPane1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(254, 254, 254), 5, true));
        jScrollPane1.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane1.setViewportBorder(new javax.swing.border.LineBorder(new java.awt.Color(254, 254, 254), 5, true));

        jPanel5.setBackground(new java.awt.Color(254, 254, 254));
        jPanel5.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(254, 254, 254), 5, true));
        jPanel5.setLayout(new java.awt.GridLayout(1, 0));
        jScrollPane1.setViewportView(jPanel5);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(450, 100, 50, 40);

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Contraseña");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(710, 80, 135, 29);

        jButton9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/m_Agregar.png"))); // NOI18N
        jButton9.setToolTipText("Crear carpeta");
        jButton9.setBorderPainted(false);
        jButton9.setContentAreaFilled(false);
        jButton9.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton9.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                jButton9ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton9);
        jButton9.setBounds(590, 190, 20, 20);

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Nombre de la carpeta");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(600, 130, 200, 19);

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("LLena todos los campos");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(710, 70, 192, 20);

        jButton12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/m_70287.png"))); // NOI18N
        jButton12.setToolTipText("Eliminar carpeta");
        jButton12.setBorderPainted(false);
        jButton12.setContentAreaFilled(false);
        jButton12.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton12.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                jButton12ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton12);
        jButton12.setBounds(330, 200, 20, 20);

        jButton17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/m_70287.png"))); // NOI18N
        jButton17.setToolTipText("Eliminar correos");
        jButton17.setBorderPainted(false);
        jButton17.setContentAreaFilled(false);
        jButton17.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton17.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                jButton17ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton17);
        jButton17.setBounds(570, 80, 20, 20);

        bCarpetas.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        bCarpetas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/carp (2).png"))); // NOI18N
        bCarpetas.setText("Carpetas");
        bCarpetas.setBorder(null);
        bCarpetas.setContentAreaFilled(false);
        bCarpetas.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        bCarpetas.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        bCarpetas.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                bCarpetasActionPerformed(evt);
            }
        });
        jPanel1.add(bCarpetas);
        bCarpetas.setBounds(70, 200, 130, 59);

        jButton7.setBackground(new java.awt.Color(255, 255, 255));
        jButton7.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jButton7.setText("Registrar");
        jButton7.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 6, true));
        jButton7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton7.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                jButton7ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton7);
        jButton7.setBounds(810, 30, 50, 20);

        bCuentas.setBackground(new java.awt.Color(0, 0, 0));
        bCuentas.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        bCuentas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/m_Account-PNG (1).png"))); // NOI18N
        bCuentas.setText("Cuenta");
        bCuentas.setBorder(null);
        bCuentas.setContentAreaFilled(false);
        bCuentas.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        bCuentas.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        bCuentas.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                bCuentasActionPerformed(evt);
            }
        });
        jPanel1.add(bCuentas);
        bCuentas.setBounds(10, 90, 120, 51);

        jButton10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/m_Edit-pencil-outline-in-circular-button.svg.png"))); // NOI18N
        jButton10.setToolTipText("Modificar carpeta");
        jButton10.setBorderPainted(false);
        jButton10.setContentAreaFilled(false);
        jButton10.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton10.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                jButton10ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton10);
        jButton10.setBounds(160, 100, 30, 30);

        jPasswordField1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPasswordField1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 5, true));
        jPanel1.add(jPasswordField1);
        jPasswordField1.setBounds(470, 60, 11, 32);

        jTextField1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jTextField1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 5, true));
        jPanel1.add(jTextField1);
        jTextField1.setBounds(410, 30, 11, 32);

        jPanel3.setBackground(new java.awt.Color(245, 245, 245));
        jPanel3.setLayout(null);

        bMenu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/m_880209-200.png"))); // NOI18N
        bMenu.setToolTipText("Ocultar");
        bMenu.setBorderPainted(false);
        bMenu.setContentAreaFilled(false);
        bMenu.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        bMenu.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                bMenuActionPerformed(evt);
            }
        });
        jPanel3.add(bMenu);
        bMenu.setBounds(10, 20, 50, 50);

        jPanel1.add(jPanel3);
        jPanel3.setBounds(0, 0, 70, 700);

        jPanel8.setBackground(new java.awt.Color(245, 245, 245));
        jPanel8.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(245, 245, 245), 5, true));
        jPanel8.setForeground(new java.awt.Color(255, 102, 102));

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        jPanel1.add(jPanel8);
        jPanel8.setBounds(620, 0, 30, 30);

        jButton11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/m_Agregar.png"))); // NOI18N
        jButton11.setToolTipText("Enviar correo nuevo");
        jButton11.setBorderPainted(false);
        jButton11.setContentAreaFilled(false);
        jButton11.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton11.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                jButton11ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton11);
        jButton11.setBounds(330, 30, 20, 20);

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("Correos");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(650, 290, 100, 29);

        jTextField2.setBackground(new java.awt.Color(245, 245, 245));
        jTextField2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jTextField2.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        jTextField2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(245, 245, 245), 5, true));
        jTextField2.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                jTextField2ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField2);
        jTextField2.setBounds(820, 290, 80, 25);

        bBuscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/m_680933_button_512x512 (5).png"))); // NOI18N
        bBuscar.setToolTipText("Buscar correo");
        bBuscar.setBorderPainted(false);
        bBuscar.setContentAreaFilled(false);
        bBuscar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        bBuscar.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                bBuscarActionPerformed(evt);
            }
        });
        jPanel1.add(bBuscar);
        bBuscar.setBounds(660, 180, 30, 30);

        jScrollPane2.setBackground(new java.awt.Color(245, 245, 245));
        jScrollPane2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(245, 245, 245), 5, true));
        jScrollPane2.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane2.setToolTipText("");
        jScrollPane2.setViewportBorder(new javax.swing.border.LineBorder(new java.awt.Color(245, 245, 245), 5, true));

        jPanel7.setBackground(new java.awt.Color(245, 245, 245));
        jPanel7.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(245, 245, 245), 5, true));
        jPanel7.setLayout(new java.awt.GridLayout(1, 0));
        jScrollPane2.setViewportView(jPanel7);

        jPanel1.add(jScrollPane2);
        jScrollPane2.setBounds(370, 180, 60, 70);

        jPanel6.setBackground(new java.awt.Color(252, 252, 252));

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        jPanel1.add(jPanel6);
        jPanel6.setBounds(690, 190, 30, 30);

        jTextField3.setEditable(false);
        jTextField3.setBackground(new java.awt.Color(245, 245, 245));
        jTextField3.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jTextField3.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(245, 245, 245), 5, true));
        jPanel1.add(jTextField3);
        jTextField3.setBounds(820, 180, 80, 25);

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(248, 248, 248));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel6.setText("Asunto:");
        jPanel1.add(jLabel6);
        jLabel6.setBounds(580, 460, 160, 22);

        jTextField4.setBackground(new java.awt.Color(245, 245, 245));
        jTextField4.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jTextField4.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(245, 245, 245), 5, true));
        jPanel1.add(jTextField4);
        jTextField4.setBounds(790, 250, 80, 25);

        jLabel7.setBackground(new java.awt.Color(248, 248, 248));
        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(248, 248, 248));
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel7.setText("De:");
        jPanel1.add(jLabel7);
        jLabel7.setBounds(640, 380, 100, 22);

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(248, 248, 248));
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel8.setText("Para:");
        jPanel1.add(jLabel8);
        jLabel8.setBounds(580, 420, 160, 22);

        jTextField5.setBackground(new java.awt.Color(245, 245, 245));
        jTextField5.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jTextField5.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(245, 245, 245), 5, true));
        jPanel1.add(jTextField5);
        jTextField5.setBounds(840, 150, 80, 25);

        bEnviarC.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/enviar (1) (1) (1).png"))); // NOI18N
        bEnviarC.setToolTipText("Enviar correo");
        bEnviarC.setBorderPainted(false);
        bEnviarC.setContentAreaFilled(false);
        bEnviarC.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        bEnviarC.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                bEnviarCActionPerformed(evt);
            }
        });
        jPanel1.add(bEnviarC);
        bEnviarC.setBounds(950, 50, 30, 33);

        jTextArea1.setBackground(new java.awt.Color(245, 245, 245));
        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jTextArea1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(245, 245, 245), 5, true));
        jScrollPane3.setViewportView(jTextArea1);

        jPanel1.add(jScrollPane3);
        jScrollPane3.setBounds(770, 380, 172, 82);

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/MicrosoftTeams-image (4) (1).png"))); // NOI18N
        jPanel1.add(jLabel12);
        jLabel12.setBounds(230, 470, 1244, 700);

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Fondo11.jpg"))); // NOI18N
        jPanel1.add(jLabel9);
        jLabel9.setBounds(530, 120, 640, 1136);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 1200, 700);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void bMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bMenuActionPerformed
        // TODO add your handling code here:
        jButton21.setVisible(false);
        jPanel11.setVisible(false);
        opci = true;
        pan.setVisible(false);
        colo = true;
        bt = true;
        bt2 = true;
        jPanel4.setVisible(false);
        jScrollPane1.setVisible(false);
        jButton8.setVisible(false);
        jPanel8.setVisible(false);
        jLabel3.setVisible(false);
        jButton7.setVisible(false);
        jTextField1.setVisible(false);
        jLabel4.setVisible(false);
        jButton9.setVisible(false);
        jPasswordField1.setVisible(false);
        jLabel1.setVisible(false);
        jLabel2.setVisible(false);
        agr = true;
        moif = true;
        if (x == true)
        {
            bCarpetas.setVisible(true);
            bCuentas.setVisible(true);
            bConfCuentas.setVisible(true);
            jPanel3.setBounds(0, 0, 265, 700);
            bMenu.setLocation(10, 20);
            x = false;
            bCarpetas.setLocation(10, 150);
            bPersonalizar.setVisible(true);
            bCerrarS.setVisible(true);
            jPanel6.setBounds(265, 0, 400, 700);
            jLabel5.setBounds(290, 20, 350, 20);
            jScrollPane2.setBounds(290, 100, 350, 550);
            jTextField2.setBounds(290, 60, 220, 30);
            jButton11.setLocation(550, 65);
            bBuscar.setLocation(512, 60);
        } else
        {
            jButton10.setVisible(false);
            jButton12.setVisible(false);
            bConfCuentas.setVisible(false);
            jPanel3.setBounds(0, 0, 70, 700);
            bMenu.setLocation(10, 20);
            bCarpetas.setVisible(false);
            bCuentas.setVisible(false);
            jPanel6.setBounds(70, 0, 595, 700);
            jLabel5.setBounds(95, 20, 445, 20);
            jScrollPane2.setBounds(95, 100, 545, 550);
            jTextField2.setBounds(95, 60, 415, 30);
            jButton11.setLocation(550, 65);
            bBuscar.setLocation(512, 60);
            x = true;
            //jPanel2.setVisible(false);
            bPersonalizar.setVisible(false);
            bCerrarS.setVisible(false);
        }
    }//GEN-LAST:event_bMenuActionPerformed

    private void bCarpetasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCarpetasActionPerformed
        // TODO add your handling code here:
        des();
        jButton12.setVisible(false);
        if (bt == true)
        {
            jButton8.setVisible(true);
            jPanel2.setVisible(true);
            //jLabel4.setVisible(false);
            //jButton9.setVisible(false);

            if (bt2 == true)
            {
                jButton8.setLocation(150, 170);
                jButton8.setVisible(true);
                jPanel4.setVisible(true);
                jPanel4.setBounds(10, 215, 240, 160);
                bt2 = false;
            } else
            {
                jButton8.setVisible(false);
                jPanel4.setVisible(false);
                bt2 = true;
            }
        } else
        {
            if (bt2 == true)
            {
                jButton8.setLocation(150, 335);
                jButton8.setVisible(true);
                jPanel4.setVisible(true);
                jPanel4.setBounds(10, 380, 240, 160);
                bt2 = false;
            } else
            {
                jButton8.setVisible(false);
                jPanel4.setVisible(false);
                bt2 = true;
            }
            
        }
    }//GEN-LAST:event_bCarpetasActionPerformed

    private void bCuentasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCuentasActionPerformed
        // TODO add your handling code here:
        jButton12.setVisible(false);
        jButton10.setVisible(false);
        if (bt == true)
        {
            bt = false;
            jScrollPane1.setVisible(true);
            jScrollPane1.setBounds(10, 150, 240, 160);
            bCarpetas.setLocation(10, 315);
            jPanel4.setBounds(10, 380, 240, 160);
            jButton8.setLocation(150, 335);
            actualiza();
        } else
        {
            jButton10.setVisible(false);
            bt = true;
            jScrollPane1.setVisible(false);
            bCarpetas.setLocation(10, 150);
            jPanel4.setBounds(10, 215, 240, 160);
            jButton8.setLocation(150, 170);
            des();
        }
    }//GEN-LAST:event_bCuentasActionPerformed

    private void bRegistroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bRegistroActionPerformed
        // TODO add your handling code here:
        bInicarS.setVisible(false);
        bRegistro.setVisible(false);
        jTextField1.setVisible(true);
        jPasswordField1.setVisible(true);
        jLabel1.setVisible(true);
        jLabel2.setVisible(true);
        jButton7.setVisible(true);
        jButton7.setText("Registrarse");
        bRegresar.setVisible(true);
        jTextField1.setBounds(945, 100, 200, 50);
        jPasswordField1.setBounds(945, 200, 200, 50);
        jLabel1.setBounds(945, 50, 200, 50);
        jLabel2.setBounds(945, 150, 200, 50);
        jButton7.setBounds(945, 330, 200, 50);

    }//GEN-LAST:event_bRegistroActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
        jLabel3.setBounds(916, 410, 250, 50);
        boolean coex = true;
        if ("Registrarse".equals(jButton7.getText()))
        {
            if (!"".equals(jTextField1.getText()) || !"".equals(jPasswordField1.getText()))
            {
                if (ml.getR() != null)
                {
                    Nodo aux = ml.getR();
                    while (aux != null)
                    {
                        String et[] = aux.getEtiqueta().split("# ");
                        if (et[0].equals(jTextField1.getText()))
                        {
                            coex = true;
                            break;
                        } else
                        {
                            coex = false;
                            aux = aux.getSig();
                        }
                    }
                    if (coex == true)
                    {
                        UIManager.put("control", nc);
                        UIManager.put("OptionPane.messageFont", f);
                        JOptionPane.showMessageDialog(null, "Cuenta existente. Intenta de nuevo");
                    } else
                    {
                        
                        String PATRON4 = "^[A-Za-z][A-Za-z\\d_.]+@[a-z]+(.[a-z]+)(.[a-z]+){1,3}$"; //CORREO
                        Pattern pa = Pattern.compile(PATRON4);
                        Matcher maa = pa.matcher(jTextField1.getText());
                        boolean r = maa.matches();
                        if (r == true)
                        {
                            String d[] = new String[1];
                            d[0] = jTextField1.getText() + "# " + jPasswordField1.getText();
                            Nodo h1 = new Nodo(d[0], d[0]);
                            ml.setR(ml.inserta(h1, d, 0, ml.getR()));
                            nv = d[0];
                            
                            String dee[] = new String[2];
                            dee[0] = nv;
                            dee[1] = "Borradores";
                            Nodo borr = new Nodo(dee[1], dee[1]);
                            ml.setR(ml.inserta(borr, dee, 0, ml.getR()));
                            
                            dee[1] = "Principal";
                            Nodo pri = new Nodo(dee[1], dee[1]);
                            ml.setR(ml.inserta(pri, dee, 0, ml.getR()));
                            actualiza2();
                            String nt = "";
                            //System.out.println(ml.consulta(ml.getR(), nt));
                            login();
                            jLabel12.setVisible(false);
                            bRegresar.setVisible(false);
                        } else
                        {
                            UIManager.put("control", nc);
                            UIManager.put("OptionPane.messageFont", f);
                            JOptionPane.showMessageDialog(null, "Formato de cuenta incorrecto. Empiece con una letra, siguiendo el \npatron ****@***.***");
                        }
                    }
                } else
                {
                    String PATRON4 = "^[A-Za-z][A-Za-z\\d_.]+@[a-z]+(.[a-z]+)(.[a-z]+){1,3}$"; //CORREO
                    Pattern pa = Pattern.compile(PATRON4);
                    Matcher maa = pa.matcher(jTextField1.getText());
                    boolean r = maa.matches();
                    if (r == true)
                    {
                        String d[] = new String[1];
                        d[0] = jTextField1.getText() + "# " + jPasswordField1.getText();
                        Nodo h1 = new Nodo(d[0], d[0]);
                        ml.setR(ml.inserta(h1, d, 0, ml.getR()));
                        nv = d[0];
                        
                        String dee[] = new String[2];
                        dee[0] = nv;
                        dee[1] = "Borradores";
                        Nodo borr = new Nodo(dee[1], dee[1]);
                        ml.setR(ml.inserta(borr, dee, 0, ml.getR()));
                        
                        dee[1] = "Principal";
                        Nodo pri = new Nodo(dee[1], dee[1]);
                        ml.setR(ml.inserta(pri, dee, 0, ml.getR()));
                        String nt = "";
                        //System.out.println(ml.consulta(ml.getR(), nt));
                        login();
                        jLabel12.setVisible(false);
                        bRegresar.setVisible(false);
                        actualiza2();
                    } else
                    {
                        UIManager.put("control", nc);
                        UIManager.put("OptionPane.messageFont", f);
                        JOptionPane.showMessageDialog(null, "Formato de cuenta incorrecto. Empiece con una letra, siguiendo el \npatron ****@***.***");
                    }
                }
            } else
            {
                UIManager.put("control", nc);
                UIManager.put("OptionPane.messageFont", f);
                JOptionPane.showMessageDialog(null, "Llena todos los campos");
            }
        } else
        {
            if (!"".equals(jTextField1.getText()) || !"".equals(jPasswordField1.getText()))
            {
                if (ml.getR() != null)
                {
                    Nodo aux = ml.getR();
                    while (aux != null)
                    {
                        String et[] = aux.getEtiqueta().split("# ");
                        if (et[0].equals(jTextField1.getText()) && jPasswordField1.getText().equals(et[1]))
                        {
                            
                            coex = true;
                            nv = aux.getEtiqueta();
                            //System.out.println("Ingresa con nv:" + nv);
                            break;
                        } else
                        {
                            coex = false;
                            aux = aux.getSig();
                        }
                    }
                    if (coex == true)
                    {
                        login();
                        bRegresar.setVisible(false);
                        jLabel12.setVisible(false);
                        actualiza2();
                    } else
                    {
                        UIManager.put("control", nc);
                        UIManager.put("OptionPane.messageFont", f);
                        JOptionPane.showMessageDialog(null, "Datos incorrectos");
                    }
                } else
                {
                    UIManager.put("control", nc);
                    UIManager.put("OptionPane.messageFont", f);
                    JOptionPane.showMessageDialog(null, "No existe la cuenta");
                }
            } else
            {
                UIManager.put("control", nc);
                UIManager.put("OptionPane.messageFont", f);
                JOptionPane.showMessageDialog(null, "Llena todos los campos");
            }
        }
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        // TODO add your handling code here:
        jPanel11.setVisible(false);
        jButton23.setVisible(false);
        opci = true;
        moif = true;
        jButton21.setVisible(false);
        if (agr == true)
        {
            borrRegis();
            borraCuadroElimina();
            jTextField1.setText("");
            //System.out.println("NV real: " + nv);
            jLabel4.setText("Nombre de la carpeta");
            jPanel8.setVisible(true);
            jButton9.setVisible(true);
            jLabel4.setVisible(true);
            jTextField1.setVisible(true);
            jPanel8.setBounds(265, 0, 300, 100);
            jLabel4.setLocation(320, 5);
            jTextField1.setBounds(320, 30, 185, 40);
            jButton9.setLocation(520, 42);
            jPasswordField1.setVisible(false);
            jButton7.setVisible(false);
            jLabel1.setVisible(false);
            jLabel2.setVisible(false);
            if (bBuscar.isVisible() == true)
            {
                bMoverC.setVisible(true);
                jButton17.setVisible(true);
            }
            agr = false;
            jTextArea1.setVisible(false);
            jScrollPane3.setVisible(false);
            jLabel7.setVisible(false);
            jLabel6.setVisible(false);
            jLabel8.setVisible(false);
            jTextField3.setVisible(false);
            jTextField4.setVisible(false);
            jTextField5.setVisible(false);
            bEnviarC.setVisible(false);
        } else
        {
            jPanel8.setVisible(false);
            jButton9.setVisible(false);
            jLabel4.setVisible(false);
            jTextField1.setVisible(false);
            agr = true;
        }
    }//GEN-LAST:event_jButton8ActionPerformed

    private void bInicarSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bInicarSActionPerformed
        // TODO add your handling code here:
        bRegresar.setVisible(true);
        bInicarS.setVisible(false);
        bRegistro.setVisible(false);
        jTextField1.setVisible(true);
        jPasswordField1.setVisible(true);
        jLabel1.setVisible(true);
        jLabel2.setVisible(true);
        jButton7.setVisible(true);
        jButton7.setText("Ingresar");
        jTextField1.setBounds(945, 100, 200, 50);
        jPasswordField1.setBounds(945, 200, 200, 50);
        jLabel1.setBounds(945, 50, 200, 50);
        jLabel2.setBounds(945, 150, 200, 50);
        jButton7.setBounds(945, 330, 200, 50);
    }//GEN-LAST:event_bInicarSActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        // TODO add your handling code her
        jButton21.setVisible(false);
        if ("".equals(jTextField1.getText()))
        {
            UIManager.put("control", nc);
            UIManager.put("OptionPane.messageFont", f);
            JOptionPane.showMessageDialog(null, "Escriba el nombre de la carpeta");
        } else
        {
            Nodo aud = ml.getR();
            aud = ml.busca(aud, nv);
            if (aud.getAbj() != null)
            {
                aud = aud.getAbj();
                aud = ml.busca(aud, jTextField1.getText());
                if (aud == null)
                {
                    String d[] = new String[2];
                    d[0] = nv;
                    d[1] = jTextField1.getText();
                    Nodo h1 = new Nodo(jTextField1.getText(), jTextField1.getText());
                    ml.setR(ml.inserta(h1, d, 0, ml.getR()));
                    String nt = "";
                    //System.out.println(ml.consulta(ml.getR(), nt));
                    jButton9.setVisible(false);
                    jPanel8.setVisible(false);
                    jTextField1.setVisible(false);
                    jLabel4.setVisible(false);
                    jTextField1.setText("");
                    jButton9.setVisible(false);
                    jLabel4.setVisible(false);
                    jPanel4.setVisible(true);
                    nv2 = jTextField1.getText();
                    jLabel3.setVisible(false);
                    jLabel9.setVisible(false);
                    jTextField3.setVisible(false);
                    jTextField4.setVisible(false);
                    jTextField5.setVisible(false);
                    jLabel6.setVisible(false);
                    jLabel7.setVisible(false);
                    jLabel8.setVisible(false);
                    jScrollPane3.setVisible(false);
                    jPanel6.setVisible(false);
                    jLabel5.setVisible(false);
                    jScrollPane2.setVisible(false);
                    jTextField2.setVisible(false);
                    jButton11.setVisible(false);
                    bBuscar.setVisible(false);
                    bMoverC.setVisible(false);
                    jButton17.setVisible(false);
                    actualiza2();
                    agr = true;
                } else
                {
                    if (!aud.getEtiqueta().equals(jTextField1.getText()))
                    {
                        String d[] = new String[2];
                        d[0] = nv;
                        d[1] = jTextField1.getText();
                        Nodo h1 = new Nodo(jTextField1.getText(), jTextField1.getText());
                        ml.setR(ml.inserta(h1, d, 0, ml.getR()));
                        String nt = "";
                        //System.out.println(ml.consulta(ml.getR(), nt));
                        jButton9.setVisible(false);
                        jPanel8.setVisible(false);
                        jTextField1.setVisible(false);
                        jLabel4.setVisible(false);
                        jTextField1.setText("");
                        jButton9.setVisible(false);
                        jLabel4.setVisible(false);
                        jPanel4.setVisible(true);
                        nv2 = jTextField1.getText();
                        jLabel3.setVisible(false);
                        jLabel9.setVisible(false);
                        jTextField3.setVisible(false);
                        jTextField4.setVisible(false);
                        jTextField5.setVisible(false);
                        jLabel6.setVisible(false);
                        jLabel7.setVisible(false);
                        jLabel8.setVisible(false);
                        jScrollPane3.setVisible(false);
                        jPanel6.setVisible(false);
                        jLabel5.setVisible(false);
                        jScrollPane2.setVisible(false);
                        jTextField2.setVisible(false);
                        jButton11.setVisible(false);
                        bBuscar.setVisible(false);
                        bMoverC.setVisible(false);
                        jButton17.setVisible(false);
                        actualiza2();
                        agr = true;
                    } else
                    {
                        if (aud.getEtiqueta().equals(jTextField1.getText()))
                        {
                            UIManager.put("control", nc);
                            UIManager.put("OptionPane.messageFont", f);
                            JOptionPane.showMessageDialog(null, "Carpeta existente. Intenta con otro nombre");
                        }
                    }
                }
            } else
            {
                String d[] = new String[2];
                d[0] = nv;
                d[1] = jTextField1.getText();
                Nodo h1 = new Nodo(jTextField1.getText(), jTextField1.getText());
                ml.setR(ml.inserta(h1, d, 0, ml.getR()));
                String nt = "";
               //System.out.println(ml.consulta(ml.getR(), nt));
                jButton9.setVisible(false);
                jPanel8.setVisible(false);
                jTextField1.setVisible(false);
                jLabel4.setVisible(false);
                jTextField1.setText("");
                jButton9.setVisible(false);
                jLabel4.setVisible(false);
                jPanel4.setVisible(true);
                nv2 = jTextField1.getText();
                jLabel3.setVisible(false);
                jLabel9.setVisible(false);
                jTextField3.setVisible(false);
                jTextField4.setVisible(false);
                jTextField5.setVisible(false);
                jLabel6.setVisible(false);
                jLabel7.setVisible(false);
                jLabel8.setVisible(false);
                jScrollPane3.setVisible(false);
                jPanel6.setVisible(false);
                jLabel5.setVisible(false);
                jScrollPane2.setVisible(false);
                jTextField2.setVisible(false);
                jButton11.setVisible(false);
                bBuscar.setVisible(false);
                bMoverC.setVisible(false);
                jButton17.setVisible(false);
                actualiza2();
                agr = true;
            }
        }
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        // TODO add your handling code here:
        jPanel11.setVisible(false);
        jButton23.setVisible(false);
        opci = true;
        jButton9.setVisible(false);
        agr = true;
        if (moif == true)
        {
            bEnviarC.setVisible(false);
            jButton9.setVisible(false);
            jTextField1.setText("");
            jPanel8.setVisible(true);
            jPanel8.setBounds(265, 0, 300, 100);
            jLabel4.setVisible(true);
            jLabel4.setLocation(315, 5);
            jTextField1.setVisible(true);
            jLabel4.setText("Nuevo nombre de carpeta");
            jTextField1.setBounds(320, 30, 185, 40);
            jButton21.setVisible(true);
            jButton21.setLocation(520, 38);
            actualiza3();
            bMoverC.setVisible(true);
            jButton17.setVisible(true);
            jButton11.setVisible(true);
            jScrollPane3.setVisible(false);
            jLabel7.setVisible(false);
            jLabel6.setVisible(false);
            jLabel8.setVisible(false);
            jTextField3.setVisible(false);
            jTextField4.setVisible(false);
            jTextField5.setVisible(false);
            jTextArea1.setVisible(false);
            jComboBox1.setVisible(false);
            jPanel9.removeAll();
            jScrollPane4.setVisible(false);
            jPanel10.setVisible(false);
            jLabel11.setVisible(false);
            bRegresa.setVisible(false);
            moif = false;
        } else
        {
            jPanel8.setVisible(false);
            jLabel4.setVisible(false);
            jTextField1.setVisible(false);
            jButton21.setVisible(false);
            moif = true;
        }
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
        // TODO add your handling code here:
        /*borrRegis();
        jLabel5.setVisible(false);
        jTextField2.setVisible(false);
        jScrollPane2.setVisible(false);
        jTextField3.setVisible(false);
        jTextField4.setVisible(false);
        jTextField5.setVisible(false);
        jLabel6.setVisible(false);
        jLabel7.setVisible(false);
        jLabel8.setVisible(false);
        jLabel9.setVisible(false);
        jScrollPane3.setVisible(false);*/
        agr = true;
        moif = true;
        jPanel11.setVisible(false);
        opci = true;
        jButton21.setVisible(false);
        jPanel8.setVisible(false);
        jButton9.setVisible(false);
        jLabel4.setVisible(false);
        jTextField1.setVisible(false);
        actualiza3();
        bMoverC.setVisible(true);
        jButton17.setVisible(true);
        jButton11.setVisible(true);
        UIManager.put("control", nc);
        UIManager.put("OptionPane.messageFont", f);
        int confirm = JOptionPane.showConfirmDialog(null, "¿Desea eliminar la carpeta?");
        if (confirm == JOptionPane.YES_OPTION)
        {
            if (!"Borradores".equals(nv2) && !"Principal".equals(nv2))
            {
                String[] vieja = new String[2];
                vieja[0] = nv;
                vieja[1] = nv2;
                
                ml.setR(ml.elimina(ml.getR(), 0, vieja));
                
                actualiza2();
                jButton12.setVisible(false);
                jButton10.setVisible(false);
                bBuscar.setVisible(false);
                jPanel6.setVisible(false);
                jButton11.setVisible(false);
                jLabel5.setVisible(false);
                jTextField2.setVisible(false);
                jScrollPane2.setVisible(false);
                jTextField3.setVisible(false);
                jTextField4.setVisible(false);
                jTextField5.setVisible(false);
                jLabel6.setVisible(false);
                jLabel7.setVisible(false);
                jLabel8.setVisible(false);
                jLabel9.setVisible(false);
                jScrollPane3.setVisible(false);
                bMoverC.setVisible(false);
                jButton17.setVisible(false);
                jButton23.setVisible(false);
            } else
            {
                UIManager.put("control", nc);
                UIManager.put("OptionPane.messageFont", f);
                JOptionPane.showMessageDialog(null, "No se puede eliminar esta carpeta");
            }
        }
    }//GEN-LAST:event_jButton12ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        // TODO add your handling code here:
        borraCuadroElimina();
        elimAgr();
        jPanel11.setVisible(false);
        opci = true;
        
        moif = true;
        agr = true;
        jPanel8.setVisible(false);
        jLabel4.setVisible(false);
        jTextField1.setVisible(false);
        jButton21.setVisible(false);
        jButton17.setVisible(true);
        bMoverC.setVisible(true);
        bEnviarC.setVisible(true);
        jLabel9.setVisible(true);
        jTextArea1.setVisible(true);
        jTextField4.setVisible(true);
        jScrollPane3.setVisible(true);
        jLabel7.setVisible(true);
        jLabel6.setVisible(true);
        jLabel8.setVisible(true);
        jTextField3.setVisible(true);
        jTextField4.setVisible(true);
        jTextField5.setVisible(true);
        jTextField4.setEditable(true);
        jTextField5.setEditable(true);
        jTextArea1.setEditable(true);
        jTextField4.setText("");
        jTextField5.setText("");
        jTextArea1.setText("");
        String c[] = nv.split("# ");
        jTextField3.setText(c[0]);
        jButton23.setVisible(true);

    }//GEN-LAST:event_jButton11ActionPerformed

    private void bBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bBuscarActionPerformed
        // TODO add your handling code here:
        jPanel11.setVisible(false);
        opci = true;
        jButton23.setVisible(false);
        jPanel8.setVisible(false);
        jLabel4.setVisible(false);
        jButton9.setVisible(false);
        jTextField1.setVisible(false);
        jButton21.setVisible(false);
        jPanel7.removeAll();
        jPanel7.updateUI();
        jPanel9.removeAll();
        jScrollPane4.setVisible(false);
        jPanel10.setVisible(false);
        jLabel11.setVisible(false);
        bRegresa.setVisible(false);
        jComboBox1.setVisible(false);
        bEnviarC.setVisible(false);
        jTextArea1.setVisible(false);
        jTextField4.setVisible(false);
        jScrollPane3.setVisible(false);
        jLabel7.setVisible(false);
        jLabel6.setVisible(false);
        jLabel8.setVisible(false);
        jTextField3.setVisible(false);
        jTextField4.setVisible(false);
        jTextField5.setVisible(false);
        jTextField4.setEditable(false);
        jTextField5.setEditable(false);
        jTextArea1.setEditable(false);
        tha.verarboles();
        if (!"".equals(jTextField2.getText()))
        {
            String k = jTextField2.getText();
            String arro[] = tha.busqueda(k);
            jTextField2.setText("");
            if (arro != null)
            {
                bMoverC.setVisible(false);
                jButton17.setVisible(false);
                jButton11.setVisible(false);
                for (int i = 0; i < arro.length; i++)
                {
                    try
                    {
                        String etq = arro[i];
                        String btneq[] = etq.split("# ");
                        JButton boton = new JButton(btneq[1] + "            " + btneq[0]);
                        boton.setOpaque(false);
                        boton.setContentAreaFilled(false);
                        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
                        boton.setFont(f);
                        boton.setBorder(border);
                        boton.setHorizontalAlignment(HEIGHT);
                        boton.setMinimumSize(new Dimension(jPanel7.getWidth(), 30));
                        boton.setMaximumSize(new Dimension(jPanel7.getWidth(), 30));
                        boton.setPreferredSize(new Dimension(jPanel7.getWidth(), 30));
                        Nodo nivcer = ml.getR();
                        Nodo niv1;
                        Nodo niv2;
                        boolean bne = true;
                        while (nivcer != null)
                        {
                            if (nivcer.getAbj() != null)
                            {
                                niv1 = nivcer.getAbj();
                                while (niv1 != null)
                                {
                                    if (niv1.getAbj() != null)
                                    {
                                        niv2 = niv1.getAbj();
                                        while (niv2 != null)
                                        {
                                            //System.out.println(nivcer.getEtiqueta() + " " + niv1.getEtiqueta() + " " + niv2.getEtiqueta() + "\n");
                                            String cor[] = boton.getText().split("            ");
                                            String corva = cor[1] + "# " + cor[0] + "# " + "si";
                                            if (corva.equals(niv2.getEtiqueta()))
                                            {
                                                jPanel7.add(boton);
                                            }
                                            niv2 = niv2.getSig();
                                        }
                                        
                                    }
                                    niv1 = niv1.getSig();
                                }
                            }
                            nivcer = nivcer.getSig();
                        }
                        boton.addMouseListener(new MouseListener()
                        {
                            public void mouseClicked(MouseEvent e)
                            {
                                Nodo nivcer = ml.getR();
                                Nodo niv1;
                                Nodo niv2;
                                boolean bne = true;
                                while (nivcer != null)
                                {
                                    if (nivcer.getAbj() != null)
                                    {
                                        niv1 = nivcer.getAbj();
                                        while (niv1 != null)
                                        {
                                            if (niv1.getAbj() != null)
                                            {
                                                niv2 = niv1.getAbj();
                                                while (niv2 != null)
                                                {
                                                    //System.out.println(nivcer.getEtiqueta() + " " + niv1.getEtiqueta() + " " + niv2.getEtiqueta() + "\n");
                                                    String cor[] = boton.getText().split("            ");
                                                    String corva = cor[1] + "# " + cor[0] + "# " + "si";
                                                    if (corva.equals(niv2.getEtiqueta()))
                                                    {
                                                        nv = nivcer.getEtiqueta();
                                                        nv2 = niv1.getEtiqueta();
                                                        nv3 = niv2.getEtiqueta();
                                                        actualiza2();
                                                        actualiza4();
                                                        bMoverC.setVisible(false);
                                                        jButton17.setVisible(false);
                                                        jButton11.setVisible(false);
                                                    }
                                                    niv2 = niv2.getSig();
                                                }
                                                
                                            }
                                            niv1 = niv1.getSig();
                                        }
                                    }
                                    nivcer = nivcer.getSig();
                                }
                                borraCuadroElimina();
                                //actualiza4();
                                elimAgr();
                            }
                            
                            @Override
                            public void mousePressed(MouseEvent e)
                            {
                            }
                            
                            @Override
                            public void mouseReleased(MouseEvent e)
                            {
                            }
                            
                            @Override
                            public void mouseEntered(MouseEvent e)
                            {
                            }
                            
                            @Override
                            public void mouseExited(MouseEvent e)
                            {
                            }
                        }
                        );
                    } catch (Exception e)
                    {
                    }
                }
                jTextField2.setText("");
            }
            jPanel7.updateUI();
        } else
        {
            UIManager.put("control", nc);
            UIManager.put("OptionPane.messageFont", f);
            JOptionPane.showMessageDialog(null, "Debe ingresar el correo a buscar");
        }
        

    }//GEN-LAST:event_bBuscarActionPerformed

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField2ActionPerformed

    private void bEnviarCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bEnviarCActionPerformed
        // TODO add your handling code here:
        if (!"Borradores".equals(nv2))
        {
            if ("".equals(jTextArea1.getText()) || "".equals(jTextField5.getText()) || "".equals(jTextField4.getText()))
            {
                UIManager.put("control", nc);
                UIManager.put("OptionPane.messageFont", f);
                JOptionPane.showMessageDialog(null, "Llena todos los campos");
            } else
            {
                String PATRON4 = "[A-Z][\\w\\d]+"; //CORREO
                Pattern pa = Pattern.compile(PATRON4);
                Matcher maa = pa.matcher(jTextField5.getText());
                boolean r = maa.matches();
                if (r == true)
                {
                    jLabel10.setVisible(false);
                    String nt = "";
                    String timeStamp = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());
                    String d[] = new String[3];
                    d[0] = nv;
                    d[1] = nv2;
                    d[2] = jTextField5.getText() + "# " + timeStamp + "# " + "si";
                    Nodo h1 = new Nodo(d[2], d[2]);
                    NodoArbol abe = new NodoArbol(d[2], d[2]);
                    tha.insertaTH(jTextField5.getText() + "# " + timeStamp + "# " + "si", abe);
                    //ab.setR(ab.inserta(ab.getR(), abe));
                    ml.setR(ml.inserta(h1, d, 0, ml.getR()));
                    nv3 = d[2];
                    actualiza3();
                    String fn[] = new String[4];
                    fn[0] = nv;
                    fn[1] = nv2;
                    fn[2] = nv3;
                    fn[3] = jTextField3.getText() + "# " + jTextField4.getText() + "# " + jTextArea1.getText();
                    Nodo h3 = new Nodo(fn[3], fn[3]);
                    ml.setR(ml.inserta(h3, fn, 0, ml.getR()));
                    //System.out.println(ml.consulta(ml.getR(), nt));
                    jTextField3.setVisible(false);
                    jTextField4.setVisible(false);
                    jTextField5.setVisible(false);
                    jTextArea1.setVisible(false);
                    jLabel6.setVisible(false);
                    jLabel7.setVisible(false);
                    jLabel8.setVisible(false);
                    bEnviarC.setVisible(false);
                    jScrollPane3.setVisible(false);
                    jTextField4.setText("");
                    jTextField5.setText("");
                    jTextArea1.setText("");
                    jButton23.setVisible(false);
                } else
                {
                    UIManager.put("control", nc);
                    UIManager.put("OptionPane.messageFont", f);
                    JOptionPane.showMessageDialog(null, "Formato de asunto no valido. Empiece con una letra mayúscula.\nSolo se aceptan letras y números");
                }
            }
        } else
        {
            if ("".equals(jTextArea1.getText()) || "".equals(jTextField5.getText()) || "".equals(jTextField4.getText()))
            {
                UIManager.put("control", nc);
                UIManager.put("OptionPane.messageFont", f);
                JOptionPane.showMessageDialog(null, "Llena todos los campos");
            } else
            {
                String PATRON4 = "[A-Z][\\w\\d]+"; //CORREO
                Pattern pa = Pattern.compile(PATRON4);
                Matcher maa = pa.matcher(jTextField5.getText());
                boolean r = maa.matches();
                if (r == true)
                {
                    String timeStamp = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());
                    Nodo aux = ml.busca(ml.getR(), nv);
                    aux = aux.getAbj();
                    aux = ml.busca(aux, nv2);
                    aux = aux.getAbj();
                    aux = ml.busca(aux, nv3);
                    String xs = jTextField3.getText() + "# " + jTextField4.getText() + "# " + jTextArea1.getText();
                    String vi[] = new String[3];
                    vi[0] = nv;
                    vi[1] = nv2;
                    vi[2] = nv3;
                    String vi2[] = new String[3];
                    vi2[0] = nv;
                    vi2[1] = nv2;
                    vi2[2] = jTextField5.getText() + "# " + timeStamp + "# " + "si";
                    ml.modificar(jTextField5.getText() + "# " + timeStamp + "# " + "si", aux, vi, vi2);
                    nv3 = vi2[2];
                    aux = aux.getAbj();
                    String cua[] = new String[4];
                    cua[0] = nv;
                    cua[1] = nv2;
                    cua[2] = nv3;
                    cua[3] = aux.getEtiqueta();
                    String cua2[] = new String[4];
                    cua2[0] = nv;
                    cua2[1] = nv2;
                    cua2[2] = nv3;
                    cua2[3] = xs;
                    actualiza3();
                    ml.modificar(xs, aux, cua, cua2);
                    
                    jLabel10.setVisible(false);
                    String[] vieja2 = new String[3];
                    vieja2[0] = nv;
                    vieja2[1] = "Borradores";
                    vieja2[2] = nv3;
                    String nueva2[] = new String[3];
                    nueva2[0] = nv;
                    nueva2[1] = "Principal";
                    nueva2[2] = jTextField5.getText() + "# " + timeStamp + "# " + "si";
                   //System.out.println(nv + " " + nueva2[1] + " " + nueva2[2]);
                    ml.setR(ml.mover(ml.getR(), 0, vieja2, nueva2));
                    actualiza3();
                    jTextField3.setVisible(false);
                    jTextField4.setVisible(false);
                    jTextField5.setVisible(false);
                    jTextArea1.setVisible(false);
                    jLabel6.setVisible(false);
                    jLabel7.setVisible(false);
                    jLabel8.setVisible(false);
                    bEnviarC.setVisible(false);
                    jScrollPane3.setVisible(false);
                    jTextField4.setText("");
                    jTextField5.setText("");
                    jTextArea1.setText("");
                    jButton23.setVisible(false);
                } else
                {
                    UIManager.put("control", nc);
                    UIManager.put("OptionPane.messageFont", f);
                    JOptionPane.showMessageDialog(null, "Formato de asunto no valido. Empiece con una letra mayúscula.\nSolo se aceptan letras y números");
                }
            }
            
        }
    }//GEN-LAST:event_bEnviarCActionPerformed

    private void bPersonalizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bPersonalizarActionPerformed
        // TODO add your handling code here:;
        if (colo == true)
        {
            pan.setVisible(true);
            colo = false;
        } else
        {
            pan.setVisible(false);
            colo = true;
        }

    }//GEN-LAST:event_bPersonalizarActionPerformed

    private void jButton17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton17ActionPerformed
        // TODO add your handling code here:
        jPanel11.setVisible(false);
        opci = true;
        jButton9.setVisible(false);
        jPanel8.setVisible(false);
        jLabel4.setVisible(false);
        jTextField1.setVisible(false);
        jButton21.setVisible(false);
        moif = true;
        agr = true;
        bElimina.setText("Eliminar");
        muestra = 0;
        jScrollPane4.setBounds(710, 80, 450, 200);
        jLabel11.setText("Selecciona los correos a eliminar");
        jComboBox1.setVisible(false);
        jTextField3.setVisible(false);
        jTextField4.setVisible(false);
        jTextField5.setVisible(false);
        jLabel6.setVisible(false);
        jLabel7.setVisible(false);
        jLabel8.setVisible(false);
        jScrollPane3.setVisible(false);
        borraCuadroElimina();
        borrRegis();
        actualiza2();
        jButton23.setVisible(false);
        if (!"Borradores".equals(nv2))
        {
            bMoverC.setVisible(true);
        } else
        {
            bMoverC.setVisible(false);
        }
        bEnviarC.setVisible(false);
        
        jButton17.setVisible(true);
        muestraCo();

    }//GEN-LAST:event_jButton17ActionPerformed

    private void bEliminaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bEliminaActionPerformed
        // TODO add your handling code here:
        switch (muestra)
        {
            case 0:
                UIManager.put("control", nc);
                UIManager.put("OptionPane.messageFont", f);
                int confirm = JOptionPane.showConfirmDialog(null, "¿Deseas eliminar los correos?");
                if (confirm == JOptionPane.YES_OPTION)
                {
                    for (int i = 0; i < Corr.size(); i++)
                    {
                        String[] vieja = new String[3];
                        vieja[0] = nv;
                        vieja[1] = nv2;
                        vieja[2] = Corr.get(i).getEtiqueta();
                        //System.out.println(vieja[2] + "\n");
                        tha.elimina(Corr.get(i).getEtiqueta());
                        ml.setR(ml.elimina(ml.getR(), 0, vieja));
                    }
                    actualiza3();
                    borraCuadroElimina();
                    jTextField3.setVisible(false);
                    jTextField4.setVisible(false);
                    jTextField5.setVisible(false);
                    jTextArea1.setVisible(false);
                    jLabel6.setVisible(false);
                    jLabel7.setVisible(false);
                    jLabel8.setVisible(false);
                    bEnviarC.setVisible(false);
                    jScrollPane3.setVisible(false);
                    bMoverC.setVisible(true);
                    jButton17.setVisible(true);
                    Corr.clear();
                }
                break;
            case 1:
                UIManager.put("control", nc);
                UIManager.put("OptionPane.messageFont", f);
                int confirm2 = JOptionPane.showConfirmDialog(null, "¿Deseas mover los correos?");
                if (confirm2 == JOptionPane.YES_OPTION)
                {
                    for (int i = 0; i < Corr2.size(); i++)
                    {
                        //System.out.println(Corr2.get(i));
                    }
                    for (int i = 0; i < Corr2.size(); i++)
                    {
                        String dsd = Corr2.get(i);
                        String[] vieja2 = new String[3];
                        vieja2[0] = nv;
                        vieja2[1] = nv2;
                        vieja2[2] = dsd;
                        //System.out.println(nv + " " + nv2 + " " + Corr2.get(i));
                        String nueva2[] = new String[3];
                        nueva2[0] = nv;
                        nueva2[1] = (String) jComboBox1.getSelectedItem();
                        nueva2[2] = dsd;
                        //System.out.println(nv + " " + nueva2[1] + " " + nueva2[2]);
                        
                        ml.setR(ml.mover(ml.getR(), 0, vieja2, nueva2));
                    }
                    actualiza3();
                    Corr2.clear();
                    borraCuadroElimina();
                    bMoverC.setVisible(true);
                    jButton17.setVisible(true);
                }
                break;
        }
    }//GEN-LAST:event_bEliminaActionPerformed

    private void bRegresaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bRegresaActionPerformed
        // TODO add your handling code here:
        borraCuadroElimina();
        bMoverC.setVisible(true);
        jButton17.setVisible(true);

    }//GEN-LAST:event_bRegresaActionPerformed

    private void bMoverCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bMoverCActionPerformed
        // TODO add your handling code here:
        jPanel11.setVisible(false);
        opci = true;
        jButton9.setVisible(false);
        moif = true;
        agr = true;
        jPanel8.setVisible(false);
        jLabel4.setVisible(false);
        jTextField1.setVisible(false);
        jButton21.setVisible(false);
        jTextField3.setVisible(false);
        jTextField4.setVisible(false);
        jTextField5.setVisible(false);
        jLabel6.setVisible(false);
        jLabel7.setVisible(false);
        jLabel8.setVisible(false);
        jScrollPane3.setVisible(false);
        bElimina.setText("Mover");
        muestra = 1;
        muestraCo();
        jScrollPane4.setBounds(710, 115, 450, 165);
        jLabel11.setText("Selecciona los correos a mover");
        jComboBox1.removeAllItems();
        if (ml.getR() != null)
        {
            raizCat = ml.busca(ml.getR(), nv);
            raizCat = raizCat.getAbj();
            Nodo aux = raizCat;
            while (aux != null)
            {
                if (!aux.getEtiqueta().equals(nv2))
                {
                    jComboBox1.addItem(aux.getEtiqueta());
                    if ("Borradores".equals(aux.getEtiqueta()))
                    {
                        jComboBox1.removeItem(aux.getEtiqueta());
                    }
                }
                aux = aux.getSig();
            }
        }
        jComboBox1.setVisible(true);
        bEnviarC.setVisible(false);
        jButton23.setVisible(false);
    }//GEN-LAST:event_bMoverCActionPerformed

    private void bCerrarSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCerrarSActionPerformed
        jButton9.setVisible(false);
        jPanel8.setVisible(false);
        jLabel4.setVisible(false);
        jTextField1.setVisible(false);
        jButton21.setVisible(false);
        jButton9.setVisible(false);
        moif = true;
        agr = true;
        UIManager.put("control", nc);
        UIManager.put("OptionPane.messageFont", f);
        int confir = JOptionPane.showConfirmDialog(null, "¿Deseas cerrar sesion?");
        if (confir == JOptionPane.YES_OPTION)
        {
            login();
            borraCuadroElimina();
            des();
            elimAgr();
            jPanel8.setVisible(true);
            jPanel8.setBounds(900, 0, 300, 700);
            jPanel3.setVisible(false);
            jScrollPane1.setVisible(false);
            jPanel4.setVisible(false);
            bMenu.setVisible(false);
            bPersonalizar.setVisible(false);
            bCerrarS.setVisible(false);
            bCuentas.setVisible(false);
            bCarpetas.setVisible(false);
            jButton10.setVisible(false);
            jButton8.setVisible(false);
            jButton12.setVisible(false);
            bInicarS.setVisible(true);
            bRegistro.setVisible(true);
            jLabel12.setVisible(true);
            bConfCuentas.setVisible(false);
            x = true;
            jButton23.setVisible(false);
            jPanel3.setBounds(0, 0, 70, 700);
        }
    }//GEN-LAST:event_bCerrarSActionPerformed

    private void bRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bRegresarActionPerformed
        // TODO add your handling code here:
        login();
        borraCuadroElimina();
        des();
        elimAgr();
        jPanel8.setVisible(true);
        jPanel8.setBounds(900, 0, 300, 700);
        jPanel3.setVisible(false);
        jScrollPane1.setVisible(false);
        jPanel4.setVisible(false);
        bMenu.setVisible(false);
        bPersonalizar.setVisible(false);
        bCerrarS.setVisible(false);
        bCuentas.setVisible(false);
        bCarpetas.setVisible(false);
        jButton10.setVisible(false);
        jButton8.setVisible(false);
        jButton12.setVisible(false);
        bInicarS.setVisible(true);
        bRegistro.setVisible(true);
        jLabel12.setVisible(true);
        bRegresar.setVisible(false);
    }//GEN-LAST:event_bRegresarActionPerformed

    private void jButton21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton21ActionPerformed
        // TODO add your handling code here:
        jButton21.setVisible(false);
        if (!"".equals(jTextField1.getText()))
        {
            Nodo aux2 = ml.busca(ml.getR(), nv);
            aux2 = aux2.getAbj();
            if (aux2 != null)
            {
                aux2 = ml.busca(aux2, jTextField1.getText());
                if (aux2 == null)
                {
                    Nodo aux = ml.busca(ml.getR(), nv);
                    aux = aux.getAbj();
                    aux = ml.busca(aux, nv2);
                    if (!"Borradores".equals(aux.getEtiqueta()) && !"Principal".equals(aux.getEtiqueta()))
                    {
                        String vi[] = new String[2];
                        vi[0] = nv;
                        vi[1] = nv2;
                        String vi2[] = new String[2];
                        vi2[0] = nv;
                        vi2[1] = jTextField1.getText();
                        ml.modificar(jTextField1.getText(), aux, vi, vi2);
                        //ml.setR(ml.elimina(ml.getR(), 0, afn));

                        jButton9.setVisible(false);
                        jPanel8.setVisible(false);
                        jTextField1.setVisible(false);
                        jLabel4.setVisible(false);
                        nv2 = jTextField1.getText();
                        actualiza();
                        actualiza2();
                        jTextField1.setText("");
                        jButton21.setVisible(false);
                        moif = true;
                    } else
                    {
                        jButton9.setVisible(false);
                        jPanel8.setVisible(false);
                        jTextField1.setVisible(false);
                        jLabel4.setVisible(false);
                        jTextField1.setText("");
                        jButton21.setVisible(false);
                        UIManager.put("control", nc);
                        UIManager.put("OptionPane.messageFont", f);
                        JOptionPane.showMessageDialog(null, "No se puede modificar esta carpeta");
                    }
                } else
                {
                    jButton9.setVisible(false);
                    jPanel8.setVisible(false);
                    jTextField1.setVisible(false);
                    jLabel4.setVisible(false);
                    jTextField1.setText("");
                    jButton21.setVisible(false);
                    moif = true;
                    UIManager.put("control", nc);
                    UIManager.put("OptionPane.messageFont", f);
                    JOptionPane.showMessageDialog(null, "Intenta con otro nombre");
                }
            }
        }
    }//GEN-LAST:event_jButton21ActionPerformed

    private void bConfCuentasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bConfCuentasActionPerformed
        // TODO add your handling code here:
        agr = true;
        moif = true;
        jButton23.setVisible(false);
        jPanel9.removeAll();
        jTextArea1.setVisible(false);
        bEnviarC.setVisible(false);
        jScrollPane3.setVisible(false);
        jLabel7.setVisible(false);
        jLabel6.setVisible(false);
        jLabel8.setVisible(false);
        jTextField3.setVisible(false);
        jTextField4.setVisible(false);
        jTextField5.setVisible(false);
        jScrollPane4.setVisible(false);
        jPanel10.setVisible(false);
        jLabel11.setVisible(false);
        bRegresa.setVisible(false);
        jComboBox1.setVisible(false);
        jPanel8.setVisible(false);
        jButton9.setVisible(false);
        jLabel4.setVisible(false);
        jTextField1.setVisible(false);
        jButton21.setVisible(false);
        if (opci == true)
        {
            jPanel11.setVisible(true);
            opci = false;
        } else
        {
            jPanel11.setVisible(false);
            opci = true;
        }
    }//GEN-LAST:event_bConfCuentasActionPerformed

    private void jButton23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton23ActionPerformed
        // TODO add your handling code here:
        jButton23.setVisible(false);
        if (!"Borradores".equals(nv2))
        {
            jLabel10.setVisible(false);
            String nt = "";
            String timeStamp = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());
            if ("".equals(jTextField5.getText()))
            {
                jTextField5.setText("Borrador");
            }
            String d[] = new String[3];
            d[0] = nv;
            d[1] = "Borradores";
            d[2] = jTextField5.getText() + "# " + timeStamp + "# " + "si";
            Nodo h1 = new Nodo(d[2], d[2]);
            NodoArbol abe = new NodoArbol(d[2], d[2]);
            tha.insertaTH(jTextField5.getText() + "# " + timeStamp + "# " + "si", abe);
            //ab.setR(ab.inserta(ab.getR(), abe));
            ml.setR(ml.inserta(h1, d, 0, ml.getR()));
            nv3 = d[2];
            String fn[] = new String[4];
            if ("".equals(jTextField4.getText()))
            {
                jTextField4.setText("-");
            }
            if ("".equals(jTextArea1.getText()))
            {
                jTextArea1.setText("-");
            }
            fn[0] = nv;
            fn[1] = "Borradores";
            fn[2] = nv3;
            fn[3] = jTextField3.getText() + "# " + jTextField4.getText() + "# " + jTextArea1.getText();
            Nodo h3 = new Nodo(fn[3], fn[3]);
            ml.setR(ml.inserta(h3, fn, 0, ml.getR()));
           //System.out.println(ml.consulta(ml.getR(), nt));
            jTextField3.setVisible(false);
            jTextField4.setVisible(false);
            jTextField5.setVisible(false);
            jTextArea1.setVisible(false);
            jLabel6.setVisible(false);
            jLabel7.setVisible(false);
            jLabel8.setVisible(false);
            bEnviarC.setVisible(false);
            jScrollPane3.setVisible(false);
            jTextField4.setText("");
            jTextField5.setText("");
            jTextArea1.setText("");
        } else
        {
            if ("".equals(jTextField5.getText()))
            {
                jTextField5.setText("-");
            }
            if ("".equals(jTextField4.getText()))
            {
                jTextField4.setText("-");
            }
            if ("".equals(jTextArea1.getText()))
            {
                jTextArea1.setText("-");
            }
            String timeStamp = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());
            Nodo aux = ml.busca(ml.getR(), nv);
            aux = aux.getAbj();
            aux = ml.busca(aux, nv2);
            aux = aux.getAbj();
            aux = ml.busca(aux, nv3);
            String xs = jTextField3.getText() + "# " + jTextField4.getText() + "# " + jTextArea1.getText();
            String vi[] = new String[3];
            vi[0] = nv;
            vi[1] = nv2;
            vi[2] = nv3;
            String vi2[] = new String[3];
            vi2[0] = nv;
            vi2[1] = nv2;
            vi2[2] = jTextField5.getText() + "# " + timeStamp + "# " + "si";
            ml.modificar(jTextField5.getText() + "# " + timeStamp + "# " + "si", aux, vi, vi2);
            nv3 = vi2[2];
            aux = aux.getAbj();
            String cua[] = new String[4];
            cua[0] = nv;
            cua[1] = nv2;
            cua[2] = nv3;
            cua[3] = aux.getEtiqueta();
            String cua2[] = new String[4];
            cua2[0] = nv;
            cua2[1] = nv2;
            cua2[2] = nv3;
            cua2[3] = xs;
            actualiza3();
            ml.modificar(xs, aux, cua, cua2);
            jTextField3.setVisible(false);
            jTextField4.setVisible(false);
            jTextField5.setVisible(false);
            jTextArea1.setVisible(false);
            jLabel6.setVisible(false);
            jLabel7.setVisible(false);
            jLabel8.setVisible(false);
            bEnviarC.setVisible(false);
            jScrollPane3.setVisible(false);
            jTextField4.setText("");
            jTextField5.setText("");
            jTextArea1.setText("");
        }

    }//GEN-LAST:event_jButton23ActionPerformed
    
    public void login()
    {
        jPanel2.updateUI();
        bMenu.setVisible(true);
        jPanel3.setVisible(true);
        jLabel1.setVisible(false);
        jLabel2.setVisible(false);
        jButton7.setVisible(false);
        jPanel8.setVisible(false);
        jTextField1.setText("");
        jTextField1.setVisible(false);
        jPasswordField1.setText("");
        jPasswordField1.setVisible(false);
        jPanel2.removeAll();
        jPanel7.removeAll();
        jLabel3.setVisible(false);
        jLabel9.setVisible(false);
        jTextField3.setVisible(false);
        jTextField4.setVisible(false);
        jTextField5.setVisible(false);
        jLabel6.setVisible(false);
        jLabel7.setVisible(false);
        jLabel8.setVisible(false);
        jScrollPane3.setVisible(false);
        jPanel6.setVisible(false);
        jLabel5.setVisible(false);
        jScrollPane2.setVisible(false);
        jTextField2.setVisible(false);
        jButton11.setVisible(false);
        bBuscar.setVisible(false);
    }
    
    public void actualiza()
    {
        jPanel5.removeAll();
        String etAux = "";
        if (ml.getR() != null)
        {
            Nodo aux = ml.getR();
            while (aux != null)
            {
                etAux = aux.getEtiqueta();
                String c[] = etAux.split("# ");
                JButton boton = new JButton(c[0]);
                boton.setOpaque(false);
                boton.setBorderPainted(false);
                boton.setBackground(new Color(254, 254, 254));
                boton.setContentAreaFilled(false);
                boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
                boton.setHorizontalAlignment(HEIGHT);
                boton.setMinimumSize(new Dimension(jPanel7.getWidth(), 30));
                boton.setMaximumSize(new Dimension(jPanel7.getWidth(), 30));
                boton.setPreferredSize(new Dimension(jPanel7.getWidth(), 30));
                boton.setFont(f);
                jPanel5.add(boton);
                boton.addActionListener(new ActionListener()
                {
                    
                    public void actionPerformed(ActionEvent e)
                    {
                        if (ml.getR() != null)
                        {
                            Nodo aux = ml.getR();
                            while (aux != null)
                            {
                                String a[] = aux.getEtiqueta().split("# ");
                                //System.out.println(aux.getEtiqueta());
                                if (a[0].equals(boton.getText()))
                                {
                                    nv = aux.getEtiqueta();
                                    break;
                                }
                                aux = aux.getSig();
                            }
                            jButton21.setVisible(false);
                            borraCuadroElimina();
                            borrRegis();
                            actualiza2();
                            jButton23.setVisible(false);
                            jPanel11.setVisible(false);
                            opci = true;
                            agr = true;
                            moif = true;
                            jButton12.setVisible(false);
                            jButton10.setVisible(false);
                            bBuscar.setVisible(false);
                            jPanel6.setVisible(false);
                            jButton11.setVisible(false);
                            jLabel5.setVisible(false);
                            jTextField2.setVisible(false);
                            jScrollPane2.setVisible(false);
                            jTextField3.setVisible(false);
                            jTextField4.setVisible(false);
                            jTextField5.setVisible(false);
                            jLabel6.setVisible(false);
                            jLabel7.setVisible(false);
                            jLabel8.setVisible(false);
                            jLabel9.setVisible(false);
                            jScrollPane3.setVisible(false);
                            elimAgr();
                            bEnviarC.setVisible(false);
                        }
                    }
                }
                );
                aux = aux.getSig();
            }
        }
        jPanel2.updateUI();
    }
    
    public void actualiza2()
    {
        jPanel2.removeAll();
        if (ml.getR() != null)
        {
            raizCat = ml.busca(ml.getR(), nv);
            raizCat = raizCat.getAbj();
            Nodo aux = raizCat;
            while (aux != null)
            {
                //System.out.print(aux.getEtiqueta() + "\n");
                JButton boton = new JButton(aux.getEtiqueta());
                boton.setOpaque(false);
                boton.setBackground(new Color(254, 254, 254));
                boton.setContentAreaFilled(false);
                boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
                boton.setHorizontalAlignment(HEIGHT);
                boton.setMinimumSize(new Dimension(jPanel7.getWidth(), 30));
                boton.setMaximumSize(new Dimension(jPanel7.getWidth(), 30));
                boton.setPreferredSize(new Dimension(jPanel7.getWidth(), 30));
                boton.setFont(f);
                jPanel2.add(boton);
                boton.addActionListener(new ActionListener()
                {
                    public void actionPerformed(ActionEvent e)
                    {
                        nv2 = boton.getText();
                        borraCuadroElimina();
                        jButton10.setVisible(true);
                        jButton12.setVisible(true);
                        if (bt == true)
                        {
                            jButton10.setLocation(180, 165);
                            jButton12.setLocation(220, 170);
                        } else
                        {
                            jButton10.setLocation(180, 330);
                            jButton12.setLocation(220, 335);
                        }
                        jPanel6.setVisible(true);
                        elimAgr();
                        jButton21.setVisible(false);
                        //System.out.println(nv2);
                        agr = true;
                        moif = true;
                        jPanel11.setVisible(false);
                        jButton23.setVisible(false);
                        opci = true;
                        jScrollPane2.setVisible(true);
                        jLabel5.setVisible(true);
                        jTextField2.setVisible(true);
                        bBuscar.setVisible(true);
                        actualiza3();
                        jLabel9.setVisible(true);
                        jButton17.setVisible(true);
                        jTextField3.setVisible(false);
                        jTextField4.setVisible(false);
                        jTextField5.setVisible(false);
                        jTextArea1.setVisible(false);
                        jLabel6.setVisible(false);
                        jLabel7.setVisible(false);
                        jLabel8.setVisible(false);
                        bEnviarC.setVisible(false);
                        jScrollPane3.setVisible(false);
                        borrRegis();
                        if (!"Borradores".equals(nv2))
                        {
                            bMoverC.setVisible(true);
                            jButton11.setVisible(true);
                        } else
                        {
                            bMoverC.setVisible(false);
                            jButton11.setVisible(false);
                        }
                    }
                }
                );
                aux = aux.getSig();
            }
        }
        jPanel2.updateUI();
    }
    
    public void actualiza3()
    {
        jPanel7.removeAll();
        if (ml.getR() != null)
        {
            raizCat = ml.busca(ml.getR(), nv);
            raizCat = raizCat.getAbj();
            raizCat = ml.busca(raizCat, nv2);
            if (raizCat != null)
            {
                raizCat = raizCat.getAbj();
                Nodo aux = raizCat;
                int z = 10;
                while (aux != null)
                {
                    String c[] = aux.getEtiqueta().split("# ");
                    JButton boton = new JButton(c[1] + "            " + c[0]);
                    boton.setOpaque(false);
                    boton.setContentAreaFilled(false);
                    boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
                    boton.setFont(f);
                    boton.setBorder(border);
                    boton.setHorizontalAlignment(HEIGHT);
                    boton.setMinimumSize(new Dimension(jPanel7.getWidth(), 30));
                    boton.setMaximumSize(new Dimension(jPanel7.getWidth(), 30));
                    boton.setPreferredSize(new Dimension(jPanel7.getWidth(), 30));
                    jPanel7.add(boton);
                    boton.addMouseListener(new MouseListener()
                    {
                        public void mouseClicked(MouseEvent e)
                        {
                            String t[] = boton.getText().split("            ");
                            //System.out.println(t[1] + t[0]);
                            String aw = t[1] + "# " + t[0] + "# " + "si";
                            nv3 = aw;
                            borraCuadroElimina();
                            actualiza4();
                            elimAgr();
                            jPanel11.setVisible(false);
                            opci = true;
                            jButton17.setVisible(true);
                            agr = true;
                            moif = true;
                            if ("Borradores".equals(nv2))
                            {
                                jButton23.setVisible(true);
                                jTextField4.setEditable(true);
                                jTextField5.setEditable(true);
                                jTextArea1.setEditable(true);
                                bMoverC.setVisible(false);
                                bEnviarC.setVisible(true);
                            } else
                            {
                                jButton23.setVisible(false);
                                bMoverC.setVisible(true);
                                jTextField4.setEditable(false);
                                jTextField5.setEditable(false);
                                jTextArea1.setEditable(false);
                                bEnviarC.setVisible(false);
                            }
                        }
                        
                        @Override
                        public void mousePressed(MouseEvent e)
                        {
                        }
                        
                        @Override
                        public void mouseReleased(MouseEvent e)
                        {
                        }
                        
                        @Override
                        public void mouseEntered(MouseEvent e)
                        {
                        }
                        
                        @Override
                        public void mouseExited(MouseEvent e)
                        {
                        }
                    }
                    );
                    z += 40;
                    aux = aux.getSig();
                }
            }
        }
        jPanel7.updateUI();
    }
    
    public void borraCuadroElimina()
    {
        bRegresa.setVisible(false);
        bElimina.setVisible(false);
        jLabel11.setVisible(false);
        jPanel10.setVisible(false);
        jScrollPane4.setVisible(false);
        jButton17.setVisible(false);
        bMoverC.setVisible(false);
        jComboBox1.setVisible(false);
    }
    
    public void actualiza4()
    {
        raizCat = ml.busca(ml.getR(), nv);
        raizCat = raizCat.getAbj();
        raizCat = ml.busca(raizCat, nv2);
        raizCat = raizCat.getAbj();
        raizCat = ml.busca(raizCat, nv3);
        raizCat = raizCat.getAbj();
        if (ml.getR() != null)
        {
            Nodo aux = raizCat;
            while (aux != null)
            {
                String c[] = nv3.split("# ");
                String g[] = aux.getEtiqueta().split("# ");
                jTextField3.setVisible(true);
                jTextField4.setVisible(true);
                jTextField5.setVisible(true);
                jTextArea1.setVisible(true);
                jLabel6.setVisible(true);
                jLabel7.setVisible(true);
                jLabel8.setVisible(true);
                jScrollPane3.setVisible(true);
                jTextArea1.setText(g[2]);
                jTextArea1.setEditable(false);
                jTextField4.setText(g[1]);
                jTextField4.setEditable(false);
                jTextField3.setText(g[0]);
                jTextField3.setEditable(false);
                jTextField5.setText(c[0]);
                jTextField5.setEditable(false);
                aux = aux.getSig();
            }
        }
    }
    
    public void borrRegis()
    {
        jTextField1.setVisible(false);
        jPasswordField1.setVisible(false);
        jLabel1.setVisible(false);
        jLabel2.setVisible(false);
        jButton7.setVisible(false);
        jPanel8.setVisible(false);
        
    }
    
    public void muestraCo()
    {
        jPanel9.removeAll();
        jScrollPane4.setVisible(true);
        jPanel10.setVisible(true);
        jLabel11.setVisible(true);
        bRegresa.setVisible(true);
        
        if (ml.getR() != null)
        {
            raizCat = ml.busca(ml.getR(), nv);
            raizCat = raizCat.getAbj();
            raizCat = ml.busca(raizCat, nv2);
            raizCat = raizCat.getAbj();
            Nodo aux = raizCat;
            while (aux != null)
            {
                String c[] = aux.getEtiqueta().split("# ");
                JRadioButton boton = new JRadioButton(c[1] + "                     " + c[0]);
                boton.setFont(f);
                boton.setHorizontalAlignment(HEIGHT);
                boton.setMinimumSize(new Dimension(jPanel9.getWidth(), 25));
                boton.setMaximumSize(new Dimension(jPanel9.getWidth(), 25));
                boton.setPreferredSize(new Dimension(jPanel9.getWidth(), 25));
                jPanel9.add(boton);
                boton.addActionListener(new ActionListener()
                {
                    public void actionPerformed(ActionEvent e)
                    {
                        if (muestra == 0)
                        {
                            Nodo busc;
                            String fe[] = boton.getText().split("                     ");
                            busc = ml.Buscar(raizCat, fe[1] + "# " + fe[0] + "# " + "si");
                            if (boton.isSelected())
                            {
                                Corr.add(busc);
                                bElimina.setVisible(true);
                            } else
                            {
                                if (!boton.isSelected())
                                {
                                    Corr.remove(busc);
                                    if (Corr.isEmpty())
                                    {
                                        bElimina.setVisible(false);
                                    }
                                }
                            }
                        } else
                        {
                            //System.out.println(raizCat.getEtiqueta());
                            String fe2[] = boton.getText().split("                     ");
                            String pe = fe2[1] + "# " + fe2[0] + "# " + "si";
                            if (jComboBox1.getSelectedIndex() > -1)
                            {
                                if (boton.isSelected())
                                {
                                    Corr2.add(pe);
                                    bElimina.setVisible(true);
                                } else
                                {
                                    if (!boton.isSelected())
                                    {
                                        Corr2.remove(pe);
                                        if (Corr2.isEmpty())
                                        {
                                            bElimina.setVisible(false);
                                        }
                                    }
                                }
                                
                            }
                        }
                    }
                }
                );
                aux = aux.getSig();
            }
        }
        
        jPanel9.updateUI();
    }
    
    public void des()
    {
        jButton7.setVisible(false);
        jPasswordField1.setVisible(false);
        jLabel1.setVisible(false);
        jLabel2.setVisible(false);
        jButton10.setVisible(false);
    }
    
    public void elimAgr()
    {
        jPanel8.setVisible(false);
        jButton9.setVisible(false);
        jLabel4.setVisible(false);
        jTextField1.setVisible(false);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[])
    {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try
        {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels())
            {
                if ("Nimbus".equals(info.getName()))
                {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                    
                }
            }
        } catch (ClassNotFoundException ex)
        {
            java.util.logging.Logger.getLogger(Email.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
            
        } catch (InstantiationException ex)
        {
            java.util.logging.Logger.getLogger(Email.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
            
        } catch (IllegalAccessException ex)
        {
            java.util.logging.Logger.getLogger(Email.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
            
        } catch (javax.swing.UnsupportedLookAndFeelException ex)
        {
            java.util.logging.Logger.getLogger(Email.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable()
        {
            public void run()
            {
                new Email().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bBuscar;
    private javax.swing.JButton bCarpetas;
    private javax.swing.JButton bCerrarS;
    private javax.swing.JButton bConfCuentas;
    private javax.swing.JButton bCuentas;
    private javax.swing.JButton bElimina;
    private javax.swing.JButton bEnviarC;
    private javax.swing.JButton bInicarS;
    private javax.swing.JButton bMenu;
    private javax.swing.JButton bMoverC;
    private javax.swing.JButton bPersonalizar;
    private javax.swing.JButton bRegistro;
    private javax.swing.JButton bRegresa;
    private javax.swing.JButton bRegresar;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton17;
    private javax.swing.JButton jButton21;
    private javax.swing.JButton jButton23;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JPanel pan;
    // End of variables declaration//GEN-END:variables
}
